# Noor Al-Huda ProGuard Rules
# ================================

# Keep AdMob classes
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.ads.** { *; }

# Keep Retrofit + OkHttp
-keepattributes Signature
-keepattributes *Annotation*
-keep class retrofit2.** { *; }
-keep class okhttp3.** { *; }
-keep class okio.** { *; }

# Keep Gson model classes
-keep class com.google.gson.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Keep Glide
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule { <init>(...); }
-keep public enum com.bumptech.glide.load.ImageHeaderParser$** { *; }

# Keep Lottie
-keep class com.airbnb.lottie.** { *; }

# Keep app model classes (for JSON serialization)
-keep class com.nooralhuda.app.models.** { *; }

# Keep ViewBinding
-keep class com.nooralhuda.app.databinding.** { *; }

# Keep MyApplication
-keep class com.nooralhuda.app.MyApplication { *; }

# Keep all Activities and Fragments
-keep class com.nooralhuda.app.activities.** { *; }
-keep class com.nooralhuda.app.fragments.** { *; }
