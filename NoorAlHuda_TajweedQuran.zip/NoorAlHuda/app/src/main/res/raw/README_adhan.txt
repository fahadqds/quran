# ADHAN AUDIO PLACEHOLDER
# =========================
# To add real Adhan audio:
# 1. Download an Adhan MP3 file (e.g., from Islamic Foundation)
# 2. Rename it to: adhan_placeholder.mp3
# 3. Place it in: app/src/main/res/raw/
#
# Free Adhan audio sources:
# - https://www.islamicfinder.org/
# - Search "Adhan MP3 free download" on IslamicAudio.com
#
# This file is a placeholder. Without adhan_placeholder.mp3,
# the Adhan screen will show a toast message instead of playing audio.
