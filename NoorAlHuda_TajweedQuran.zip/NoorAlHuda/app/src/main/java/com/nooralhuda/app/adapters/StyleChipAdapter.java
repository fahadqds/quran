package com.nooralhuda.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.nooralhuda.app.R;

import java.util.List;

/**
 * StyleChipAdapter - Horizontal RecyclerView adapter for AI style selector chips.
 */
public class StyleChipAdapter extends RecyclerView.Adapter<StyleChipAdapter.ChipViewHolder> {

    private final List<String> styles;
    private final OnStyleSelectedListener listener;
    private int selectedPosition = 0;

    public interface OnStyleSelectedListener {
        void onStyleSelected(String style);
    }

    public StyleChipAdapter(List<String> styles, OnStyleSelectedListener listener) {
        this.styles = styles;
        this.listener = listener;
    }

    @NonNull @Override
    public ChipViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_style_chip, parent, false);
        return new ChipViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ChipViewHolder holder, int position) {
        String style = styles.get(position);
        holder.tvStyle.setText(style);

        // Highlight selected chip
        boolean isSelected = position == selectedPosition;
        holder.tvStyle.setSelected(isSelected);
        holder.tvStyle.setBackgroundResource(
                isSelected ? R.drawable.bg_chip_selected : R.drawable.bg_chip_default
        );
        holder.tvStyle.setTextColor(
                holder.itemView.getContext().getColor(
                        isSelected ? R.color.bg_dark : R.color.text_primary
                )
        );

        holder.itemView.setOnClickListener(v -> {
            int prev = selectedPosition;
            selectedPosition = holder.getAdapterPosition();
            notifyItemChanged(prev);
            notifyItemChanged(selectedPosition);
            listener.onStyleSelected(style);
        });
    }

    @Override
    public int getItemCount() { return styles.size(); }

    static class ChipViewHolder extends RecyclerView.ViewHolder {
        TextView tvStyle;
        ChipViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStyle = itemView.findViewById(R.id.tv_style);
        }
    }
}
