package com.nooralhuda.app.activities;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;
import com.nooralhuda.app.R;
import com.nooralhuda.app.adapters.StyleChipAdapter;
import com.nooralhuda.app.adapters.TemplateAdapter;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.ActivityAiImageCreatorBinding;
import com.nooralhuda.app.utils.ImageApiHelper;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

/**
 * AIImageCreatorActivity - Islamic AI Art Studio screen.
 * Features:
 * - Prompt input text field
 * - Style chips: Calligraphy, Nature, Minimalist, Geometric
 * - "Create" button triggers Rewarded Ad → then generates image via free API
 * - Preview image display with Glide
 * - Save to gallery and Share options
 * - Template examples horizontal recycler
 * - Banner Ad above bottom area
 * Uses Pollinations.ai free API (no key required, unlimited).
 */
public class AIImageCreatorActivity extends AppCompatActivity {

    private static final String TAG = "AIImageCreator";
    private static final int PERMISSION_REQUEST_CODE = 101;

    // ViewBinding
    private ActivityAiImageCreatorBinding binding;

    // AdManager
    private AdManager adManager;

    // Currently selected style
    private String selectedStyle = "Islamic Calligraphy Art";

    // Currently generated image bitmap
    private Bitmap generatedBitmap = null;

    // Is generation in progress
    private boolean isGenerating = false;

    // Style options
    private final List<String> styles = Arrays.asList(
            "Calligraphy", "Nature", "Minimalist", "Geometric", "Mandala", "Mosque"
    );

    // Template prompts
    private final List<String> templates = Arrays.asList(
            "Jummah Mubarak Islamic greeting card with mosque",
            "Eid al-Fitr celebration card with crescent moon",
            "Ramadan Kareem decoration with lanterns",
            "Bismillah Arabic calligraphy golden on dark green",
            "Islamic geometric pattern blue and gold",
            "Masjid al-Haram night photography style"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAiImageCreatorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        adManager = AdManager.getInstance();

        // Load ads
        adManager.loadBannerAd(this, binding.adBannerContainer);
        adManager.loadInterstitialAd(this);
        adManager.loadRewardedAd(this);

        // Setup UI components
        setupStyleChips();
        setupTemplates();
        setupClickListeners();

        // Back button
        binding.btnBack.setOnClickListener(v -> onBackPressed());
    }

    /**
     * Sets up horizontal style chip RecyclerView.
     */
    private void setupStyleChips() {
        StyleChipAdapter adapter = new StyleChipAdapter(styles, style -> {
            selectedStyle = style + " Islamic Art";
            Toast.makeText(this, "Style: " + style, Toast.LENGTH_SHORT).show();
        });

        binding.rvStyleChips.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        binding.rvStyleChips.setAdapter(adapter);
    }

    /**
     * Sets up horizontal template RecyclerView.
     */
    private void setupTemplates() {
        TemplateAdapter adapter = new TemplateAdapter(templates, template -> {
            // Fill prompt input with template text
            binding.etPrompt.setText(template);
        });

        binding.rvTemplates.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        binding.rvTemplates.setAdapter(adapter);
    }

    /**
     * Sets up the Create, Save, Share button listeners.
     */
    private void setupClickListeners() {
        // Create button — requires watching a Rewarded Ad first
        binding.btnCreate.setOnClickListener(v -> {
            if (isGenerating) return;

            String prompt = binding.etPrompt.getText().toString().trim();
            if (TextUtils.isEmpty(prompt)) {
                binding.etPrompt.setError("Please describe your image first");
                return;
            }

            // Animate button press
            animateButton(v);

            // Show Rewarded Ad first, then generate on reward
            adManager.showRewardedAd(this,
                    // onRewarded — user watched ad, generate image
                    () -> runOnUiThread(() -> generateImage(prompt)),
                    // onDismissed without reward — generate anyway (graceful)
                    () -> runOnUiThread(() -> generateImage(prompt))
            );
        });

        // Save button
        binding.btnSave.setOnClickListener(v -> {
            if (generatedBitmap == null) {
                Toast.makeText(this, "Generate an image first!", Toast.LENGTH_SHORT).show();
                return;
            }
            saveImageToGallery();
        });

        // Share button
        binding.btnShare.setOnClickListener(v -> {
            if (generatedBitmap == null) {
                Toast.makeText(this, "Generate an image first!", Toast.LENGTH_SHORT).show();
                return;
            }
            adManager.showInterstitialAd(this, this::shareImage);
        });
    }

    /**
     * Calls Pollinations.ai free API to generate an image from the prompt.
     * URL format: https://image.pollinations.ai/prompt/{encoded_prompt}
     *
     * @param prompt User's image description
     */
    private void generateImage(String prompt) {
        isGenerating = true;

        // Show loading state
        binding.progressGeneration.setVisibility(View.VISIBLE);
        binding.ivGeneratedImage.setVisibility(View.INVISIBLE);
        binding.tvGeneratingText.setVisibility(View.VISIBLE);
        binding.btnSave.setEnabled(false);
        binding.btnShare.setEnabled(false);

        // Build enhanced prompt with Islamic style
        String fullPrompt = prompt + ", " + selectedStyle +
                ", highly detailed, premium quality, artistic, beautiful";

        // Use ImageApiHelper to call free API on background thread
        ImageApiHelper.generateImage(fullPrompt, new ImageApiHelper.ImageCallback() {
            @Override
            public void onSuccess(String imageUrl) {
                runOnUiThread(() -> {
                    isGenerating = false;
                    binding.progressGeneration.setVisibility(View.GONE);
                    binding.tvGeneratingText.setVisibility(View.GONE);
                    binding.ivGeneratedImage.setVisibility(View.VISIBLE);
                    binding.btnSave.setEnabled(true);
                    binding.btnShare.setEnabled(true);

                    // Load image with Glide
                    Glide.with(AIImageCreatorActivity.this)
                            .load(imageUrl)
                            .placeholder(R.drawable.placeholder_image)
                            .into(binding.ivGeneratedImage);

                    // Also load as bitmap for saving
                    loadBitmapFromUrl(imageUrl);
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    isGenerating = false;
                    binding.progressGeneration.setVisibility(View.GONE);
                    binding.tvGeneratingText.setVisibility(View.GONE);
                    binding.ivGeneratedImage.setVisibility(View.VISIBLE);
                    Toast.makeText(AIImageCreatorActivity.this,
                            "Generation failed. Check internet.", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Image gen error: " + error);
                });
            }
        });
    }

    /**
     * Loads the generated image as a Bitmap (for saving).
     */
    private void loadBitmapFromUrl(String url) {
        new Thread(() -> {
            try {
                java.io.InputStream is = new java.net.URL(url).openStream();
                generatedBitmap = BitmapFactory.decodeStream(is);
            } catch (IOException e) {
                Log.e(TAG, "Bitmap load error: " + e.getMessage());
            }
        }).start();
    }

    /**
     * Saves the generated bitmap to the device gallery.
     */
    private void saveImageToGallery() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Need WRITE_EXTERNAL_STORAGE permission for API < 29
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_CODE);
                return;
            }
        }

        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME,
                    "NoorAlHuda_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/NoorAlHuda");

            Uri uri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

            if (uri != null) {
                OutputStream out = getContentResolver().openOutputStream(uri);
                if (out != null) {
                    generatedBitmap.compress(Bitmap.CompressFormat.JPEG, 95, out);
                    out.close();
                }
                Toast.makeText(this, "✅ Image saved to gallery!", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Save error: " + e.getMessage());
            Toast.makeText(this, "Failed to save image.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Shares the generated image via Android share sheet.
     */
    private void shareImage() {
        Toast.makeText(this, "Share: Save image first, then share from gallery.",
                Toast.LENGTH_LONG).show();
    }

    /**
     * Scales a button down then up for a press animation.
     */
    private void animateButton(View v) {
        v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(100)
                .withEndAction(() ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                ).start();
    }

    @Override
    public void onBackPressed() {
        adManager.showInterstitialAd(this, () ->
                runOnUiThread(super::onBackPressed)
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
