package com.nooralhuda.app.models;

import java.util.ArrayList;
import java.util.List;

/**
 * QuranData — Complete static data for Quran navigation.
 * Contains all 30 Parahs, 114 Surahs, 7 Manzils, 14 Sajdahs
 * with correct Taj Company page numbers (611 pages total).
 */
public class QuranData {

    // ===================== DATA MODEL =====================
    public static class QuranItem {
        public int number;
        public String name;
        public String arabicName;
        public int page;
        public int totalPages;

        public QuranItem(int number, String name, String arabicName, int page, int totalPages) {
            this.number = number;
            this.name = name;
            this.arabicName = arabicName;
            this.page = page;
            this.totalPages = totalPages;
        }
    }

    // ===================== 30 PARAHS =====================
    public static List<QuranItem> getParahs() {
        List<QuranItem> list = new ArrayList<>();
        String[] names = {
            "Alaf Lam Meem", "Sayaqool", "Tilkal Rusull", "Lan Tana Loo",
            "Wal Mohsanat", "La Yuhibbullah", "Wa Iza Samiu", "Wa Lau Annana",
            "Qalal Malao", "Wa Aalamoo", "Yatazeroon", "Wa Mamin Dabbatin",
            "Wa Ma Ubarrioo", "Rubama", "Subhanalladhi", "Qal Alam",
            "Iqtarabet", "Qadd Aflaha", "Wa Qalalladheena", "Amman Khalaq",
            "Utlu Ma Oohi", "Wa Man Yaqnut", "Wa Mali", "Faman Azlam",
            "Ilahe Yuraddo", "Ha Meem", "Qala Fama Khatbukum", "Qadd Sami Allah",
            "Tabarakallazi", "Amma"
        };
        int[] pages = {
            2, 22, 42, 62, 82, 102, 121, 142, 162, 182,
            201, 221, 241, 262, 282, 302, 322, 342, 362, 382,
            402, 422, 442, 462, 482, 502, 522, 542, 562, 582
        };
        String[] arabic = {
            "الم", "سَيَقُولُ", "تِلْكَ الرُّسُلُ", "لَن تَنَالُوا",
            "وَالْمُحْصَنَاتُ", "لَا يُحِبُّ اللَّهُ", "وَإِذَا سَمِعُوا", "وَلَوْ أَنَّنَا",
            "قَالَ الْمَلَأُ", "وَاعْلَمُوا", "يَعْتَذِرُونَ", "وَمَا مِن دَابَّةٍ",
            "وَمَا أُبَرِّئُ", "رُبَمَا", "سُبْحَانَ الَّذِي", "قَالَ أَلَمْ",
            "اقْتَرَبَتْ", "قَدْ أَفْلَحَ", "وَقَالَ الَّذِينَ", "أَمَّنْ خَلَقَ",
            "اتْلُ مَا أُوحِيَ", "وَمَن يَقْنُتْ", "وَمَالِي", "فَمَنْ أَظْلَمُ",
            "إِلَيْهِ يُرَدُّ", "حم", "قَالَ فَمَا خَطْبُكُمْ", "قَدْ سَمِعَ اللَّهُ",
            "تَبَارَكَ الَّذِي", "عَمَّ"
        };
        int[] totalP = {20,20,20,20,20,19,21,20,20,19,20,20,21,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,29};

        for (int i = 0; i < 30; i++) {
            list.add(new QuranItem(i + 1, names[i], arabic[i], pages[i], totalP[i]));
        }
        return list;
    }

    // ===================== 114 SURAHS =====================
    public static List<QuranItem> getSurahs() {
        List<QuranItem> list = new ArrayList<>();

        // Format: number, English name, Arabic name, page
        Object[][] data = {
            {1,"Al-Faatiha","الفاتحة",2}, {2,"Al-Baqara","البقرة",3},
            {3,"Aal-i-Imraan","آل عمران",51}, {4,"An-Nisaa","النساء",78},
            {5,"Al-Maaida","المائدة",107}, {6,"Al-Anaam","الأنعام",129},
            {7,"Al-Araaf","الأعراف",152}, {8,"Al-Anfaal","الأنفال",178},
            {9,"At-Tawba","التوبة",187}, {10,"Yunus","يونس",209},
            {11,"Hud","هود",222}, {12,"Yusuf","يوسف",235},
            {13,"Ar-Rad","الرعد",250}, {14,"Ibrahim","إبراهيم",255},
            {15,"Al-Hijr","الحجر",263}, {16,"An-Nahl","النحل",268},
            {17,"Al-Israa","الإسراء",283}, {18,"Al-Kahf","الكهف",294},
            {19,"Maryam","مريم",306}, {20,"Taa-Haa","طه",313},
            {21,"Al-Anbiyaa","الأنبياء",323}, {22,"Al-Hajj","الحج",332},
            {23,"Al-Muminoon","المؤمنون",342}, {24,"An-Noor","النور",351},
            {25,"Al-Furqaan","الفرقان",360}, {26,"Ash-Shuaraa","الشعراء",367},
            {27,"An-Naml","النمل",378}, {28,"Al-Qasas","القصص",386},
            {29,"Al-Ankaboot","العنكبوت",397}, {30,"Ar-Room","الروم",405},
            {31,"Luqman","لقمان",412}, {32,"As-Sajda","السجدة",416},
            {33,"Al-Ahzaab","الأحزاب",419}, {34,"Saba","سبأ",431},
            {35,"Faatir","فاطر",438}, {36,"Yaseen","يس",444},
            {37,"As-Saaffaat","الصافات",451}, {38,"Saad","ص",459},
            {39,"Az-Zumar","الزمر",466}, {40,"Al-Mumin","غافر",477},
            {41,"Fussilat","فصلت",488}, {42,"Ash-Shura","الشورى",496},
            {43,"Az-Zukhruf","الزخرف",504}, {44,"Ad-Dukhaan","الدخان",512},
            {45,"Al-Jaathiya","الجاثية",516}, {46,"Al-Ahqaf","الأحقاف",520},
            {47,"Muhammad","محمد",526}, {48,"Al-Fath","الفتح",532},
            {49,"Al-Hujuraat","الحجرات",538}, {50,"Qaaf","ق",542},
            {51,"Adh-Dhaariyat","الذاريات",547}, {52,"At-Tur","الطور",552},
            {53,"An-Najm","النجم",556}, {54,"Al-Qamar","القمر",560},
            {55,"Ar-Rahmaan","الرحمن",564}, {56,"Al-Waaqia","الواقعة",568},
            {57,"Al-Hadid","الحديد",572}, {58,"Al-Mujaadila","المجادلة",578},
            {59,"Al-Hashr","الحشر",583}, {60,"Al-Mumtahana","الممتحنة",587},
            {61,"As-Saff","الصف",591}, {62,"Al-Jumuaa","الجمعة",593},
            {63,"Al-Munafiqoon","المنافقون",595}, {64,"At-Taghaabun","التغابن",597},
            {65,"At-Talaaq","الطلاق",599}, {66,"At-Tahrim","التحريم",602},
            {67,"Al-Mulk","الملك",605}, {68,"Al-Qalam","القلم",608},
            {69,"Al-Haaqqa","الحاقة",611}, {70,"Al-Maarij","المعارج",611},
            {71,"Nooh","نوح",611}, {72,"Al-Jinn","الجن",611},
            {73,"Al-Muzzammil","المزمل",611}, {74,"Al-Muddaththir","المدثر",611},
            {75,"Al-Qiyaama","القيامة",611}, {76,"Al-Insan","الإنسان",611},
            {77,"Al-Mursalaat","المرسلات",611}, {78,"An-Naba","النبأ",611},
            {79,"An-Naaziat","النازعات",611}, {80,"Abasa","عبس",611},
            {81,"At-Takwir","التكوير",611}, {82,"Al-Infitar","الانفطار",611},
            {83,"Al-Mutaffifin","المطففين",611}, {84,"Al-Inshiqaq","الانشقاق",611},
            {85,"Al-Burooj","البروج",611}, {86,"At-Taariq","الطارق",611},
            {87,"Al-Ala","الأعلى",611}, {88,"Al-Ghashiya","الغاشية",611},
            {89,"Al-Fajr","الفجر",611}, {90,"Al-Balad","البلد",611},
            {91,"Ash-Shams","الشمس",611}, {92,"Al-Lail","الليل",611},
            {93,"Ad-Dhuha","الضحى",611}, {94,"Al-Inshirah","الشرح",611},
            {95,"At-Tin","التين",611}, {96,"Al-Alaq","العلق",611},
            {97,"Al-Qadr","القدر",611}, {98,"Al-Bayyina","البينة",611},
            {99,"Az-Zalzala","الزلزلة",611}, {100,"Al-Aadiyaat","العاديات",611},
            {101,"Al-Qaaria","القارعة",611}, {102,"At-Takaathur","التكاثر",611},
            {103,"Al-Asr","العصر",611}, {104,"Al-Humaza","الهمزة",611},
            {105,"Al-Fil","الفيل",611}, {106,"Quraish","قريش",611},
            {107,"Al-Maaoon","الماعون",611}, {108,"Al-Kawthar","الكوثر",611},
            {109,"Al-Kaafiroon","الكافرون",611}, {110,"An-Nasr","النصر",611},
            {111,"Al-Masad","المسد",611}, {112,"Al-Ikhlaas","الإخلاص",611},
            {113,"Al-Falaq","الفلق",611}, {114,"An-Naas","الناس",611}
        };

        for (Object[] d : data) {
            list.add(new QuranItem((int)d[0], (String)d[1], (String)d[2], (int)d[3], 1));
        }
        return list;
    }

    // ===================== 7 MANZILS =====================
    public static List<QuranItem> getManzils() {
        List<QuranItem> list = new ArrayList<>();
        String[][] data = {
            {"Manzil 1","مَنْزِل ١","2"},
            {"Manzil 2","مَنْزِل ٢","107"},
            {"Manzil 3","مَنْزِل ٣","209"},
            {"Manzil 4","مَنْزِل ٤","283"},
            {"Manzil 5","مَنْزِل ٥","367"},
            {"Manzil 6","مَنْزِل ٦","446"},
            {"Manzil 7","مَنْزِل ٧","543"}
        };
        for (int i = 0; i < data.length; i++) {
            list.add(new QuranItem(i+1, data[i][0], data[i][1],
                    Integer.parseInt(data[i][2]), 1));
        }
        return list;
    }

    // ===================== 14 SAJDAHS =====================
    public static List<QuranItem> getSajdahs() {
        List<QuranItem> list = new ArrayList<>();
        Object[][] data = {
            {1,"Sajda 1 (Al-Araaf 206)","سجدة ١",177},
            {2,"Sajda 2 (Ar-Rad 15)","سجدة ٢",252},
            {3,"Sajda 3 (An-Nahl 50)","سجدة ٣",273},
            {4,"Sajda 4 (Al-Israa 109)","سجدة ٤",293},
            {5,"Sajda 5 (Maryam 58)","سجدة ٥",310},
            {6,"Sajda 6 (Al-Hajj 18)","سجدة ٦",335},
            {7,"Sajda 7 (Al-Furqaan 60)","سجدة ٧",363},
            {8,"Sajda 8 (An-Naml 26)","سجدة ٨",381},
            {9,"Sajda 9 (As-Sajda 15)","سجدة ٩",417},
            {10,"Sajda 10 (Saad 24)","سجدة ١٠",461},
            {11,"Sajda 11 (Fussilat 38)","سجدة ١١",494},
            {12,"Sajda 12 (An-Najm 62)","سجدة ١٢",558},
            {13,"Sajda 13 (Al-Inshiqaq 21)","سجدة ١٣",611},
            {14,"Sajda 14 (Al-Alaq 19)","سجدة ١٤",611}
        };
        for (Object[] d : data) {
            list.add(new QuranItem((int)d[0], (String)d[1], (String)d[2], (int)d[3], 1));
        }
        return list;
    }

    // Total Quran pages (Taj Company 15-line mushaf)
    public static final int TOTAL_PAGES = 611;
}
