package com.nooralhuda.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.nooralhuda.app.R;
import com.nooralhuda.app.activities.AIImageCreatorActivity;
import com.nooralhuda.app.activities.AdhanActivity;
import com.nooralhuda.app.activities.DuaActivity;
import com.nooralhuda.app.activities.QuranActivity;
import com.nooralhuda.app.activities.TasbihActivity;
import com.nooralhuda.app.activities.ZakatActivity;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.FragmentHomeBinding;
import com.nooralhuda.app.utils.DateHelper;
import com.nooralhuda.app.utils.PrayerTimeHelper;

import java.util.Locale;

/**
 * HomeFragment — Main dashboard screen.
 * Matches design: greeting, date, prayer times card with Qibla shortcut,
 * 2×3 feature grid (Quran, Tasbih, Adhan, Image Creator, Zakat, Dua & Azkar).
 * Staggered entrance animation on load.
 * Interstitial Ad shown before every feature tap.
 */
public class HomeFragment extends Fragment {

    private static final String TAG = "HomeFragment";
    private FragmentHomeBinding binding;
    private AdManager adManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adManager = AdManager.getInstance();
        adManager.loadInterstitialAd(requireActivity());

        setupGreetingSection();
        loadPrayerTimes();
        setupFeatureGrid();
        animateCardEntrance();
    }

    /** Sets greeting + current date */
    private void setupGreetingSection() {
        binding.tvCurrentDate.setText(DateHelper.getCurrentFormattedDate());
        binding.tvGreeting.setText("As-Salaam Alaykum,");
        // Personalise from SharedPreferences if available
        String savedName = requireContext()
                .getSharedPreferences("app_prefs", android.content.Context.MODE_PRIVATE)
                .getString("user_name", "Ahmed");
        binding.tvUserName.setText(savedName);
    }

    /** Fetches prayer times from Aladhan free API */
    private void loadPrayerTimes() {
        binding.shimmerPrayer.startShimmer();
        binding.shimmerPrayer.setVisibility(View.VISIBLE);
        binding.cardPrayerTimes.setVisibility(View.INVISIBLE);

        PrayerTimeHelper helper = new PrayerTimeHelper(requireContext());
        helper.fetchPrayerTimes(new PrayerTimeHelper.PrayerTimeCallback() {
            @Override
            public void onSuccess(PrayerTimeHelper.PrayerTimes times) {
                if (!isAdded() || binding == null) return;
                requireActivity().runOnUiThread(() -> {
                    binding.shimmerPrayer.stopShimmer();
                    binding.shimmerPrayer.setVisibility(View.GONE);
                    binding.cardPrayerTimes.setVisibility(View.VISIBLE);

                    binding.tvFajrTime.setText(times.fajr);
                    binding.tvDhuhrTime.setText(times.dhuhr);
                    binding.tvAsrTime.setText(times.asr);
                    binding.tvMaghribTime.setText(times.maghrib);
                    binding.tvIshaTime.setText(times.isha);

                    highlightActivePrayer(times.activePrayer);
                });
            }

            @Override
            public void onError(String message) {
                if (!isAdded() || binding == null) return;
                requireActivity().runOnUiThread(() -> {
                    binding.shimmerPrayer.stopShimmer();
                    binding.shimmerPrayer.setVisibility(View.GONE);
                    binding.cardPrayerTimes.setVisibility(View.VISIBLE);
                    binding.tvFajrTime.setText("--:--");
                    binding.tvDhuhrTime.setText("--:--");
                    binding.tvAsrTime.setText("--:--");
                    binding.tvMaghribTime.setText("--:--");
                    binding.tvIshaTime.setText("--:--");
                    Log.e(TAG, "Prayer time error: " + message);
                });
            }
        });
    }

    /** Highlights the currently active prayer label in gold */
    private void highlightActivePrayer(String activePrayer) {
        int def    = requireContext().getColor(R.color.text_secondary);
        int active = requireContext().getColor(R.color.gold_accent);

        binding.tvFajrLabel.setTextColor(def);
        binding.tvDhuhrLabel.setTextColor(def);
        binding.tvAsrLabel.setTextColor(def);
        binding.tvMaghribLabel.setTextColor(def);
        binding.tvIshaLabel.setTextColor(def);

        if (activePrayer == null) return;
        switch (activePrayer.toLowerCase(Locale.ROOT)) {
            case "fajr":    binding.tvFajrLabel.setTextColor(active);    break;
            case "dhuhr":   binding.tvDhuhrLabel.setTextColor(active);   break;
            case "asr":     binding.tvAsrLabel.setTextColor(active);     break;
            case "maghrib": binding.tvMaghribLabel.setTextColor(active); break;
            case "isha":    binding.tvIshaLabel.setTextColor(active);    break;
        }
    }

    /** Wire up all 6 feature cards + Qibla button */
    private void setupFeatureGrid() {
        binding.cardQuran.setOnClickListener(v        -> { animateClick(v); openWithAd(QuranActivity.class); });
        binding.cardTasbih.setOnClickListener(v       -> { animateClick(v); openWithAd(TasbihActivity.class); });
        binding.cardAdhan.setOnClickListener(v        -> { animateClick(v); openWithAd(AdhanActivity.class); });
        binding.cardImageCreator.setOnClickListener(v -> { animateClick(v); openWithAd(AIImageCreatorActivity.class); });
        binding.cardZakat.setOnClickListener(v        -> { animateClick(v); openWithAd(ZakatActivity.class); });
        binding.cardDua.setOnClickListener(v          -> { animateClick(v); openWithAd(DuaActivity.class); });
        binding.btnQibla.setOnClickListener(v         -> { animateClick(v); showQiblaInfo(); });
    }

    /** Show interstitial then open activity */
    private void openWithAd(Class<?> activityClass) {
        adManager.showInterstitialAd(requireActivity(), () ->
                requireActivity().runOnUiThread(() -> {
                    Intent intent = new Intent(requireContext(), activityClass);
                    startActivity(intent);
                    requireActivity().overridePendingTransition(
                            R.anim.slide_in_right, R.anim.slide_out_left);
                }));
    }

    /** Card press scale animation */
    private void animateClick(View v) {
        v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(100)
                .withEndAction(() ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start())
                .start();
    }

    /** Simple Qibla info dialog */
    private void showQiblaInfo() {
        new android.app.AlertDialog.Builder(requireContext())
                .setTitle("🕌 Qibla Direction")
                .setMessage("The Qibla points toward the Kaaba in Mecca, Saudi Arabia.\n\n" +
                        "Face the direction shown by a compass for your location.\n\n" +
                        "May Allah accept your prayers. 🤲")
                .setPositiveButton("OK", null)
                .show();
    }

    /** Staggered entrance animation — cards slide up + fade in */
    private void animateCardEntrance() {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (binding == null) return;
            View[] views = {
                    binding.headerSection, binding.shimmerPrayer,
                    binding.tvFeaturesLabel, binding.cardQuran,
                    binding.cardTasbih, binding.cardAdhan,
                    binding.cardImageCreator, binding.cardZakat, binding.cardDua
            };
            for (int i = 0; i < views.length; i++) {
                View v = views[i];
                if (v == null) continue;
                v.setAlpha(0f);
                v.setTranslationY(50f);
                v.animate().alpha(1f).translationY(0f)
                        .setDuration(400).setStartDelay(i * 70L).start();
            }
        }, 80);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (binding != null) binding.shimmerPrayer.stopShimmer();
        binding = null;
    }
}
