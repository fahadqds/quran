package com.nooralhuda.app.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.nooralhuda.app.adapters.DuaAdapter;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.ActivityDuaBinding;
import com.nooralhuda.app.models.DuaModel;

import java.util.ArrayList;
import java.util.List;

/**
 * DuaActivity - Dua & Azkar screen.
 * Shows categorized list of authentic Islamic supplications.
 * Includes search, category tabs, Banner Ad.
 */
public class DuaActivity extends AppCompatActivity {

    private ActivityDuaBinding binding;
    private AdManager adManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDuaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        adManager = AdManager.getInstance();
        adManager.loadBannerAd(this, binding.adBannerContainer);
        adManager.loadInterstitialAd(this);

        // Load duas
        List<DuaModel> duas = getDuaList();
        DuaAdapter adapter = new DuaAdapter(duas);

        binding.rvDuas.setLayoutManager(new LinearLayoutManager(this));
        binding.rvDuas.setAdapter(adapter);

        binding.btnBack.setOnClickListener(v -> onBackPressed());
    }

    /**
     * Returns a list of authentic Islamic duas.
     */
    private List<DuaModel> getDuaList() {
        List<DuaModel> list = new ArrayList<>();

        list.add(new DuaModel(
                "Morning Dua",
                "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ",
                "Asbahna wa asbahal mulku lillah",
                "We have reached the morning and the whole kingdom belongs to Allah.",
                "Morning & Evening"
        ));

        list.add(new DuaModel(
                "Before Eating",
                "بِسْمِ اللَّهِ",
                "Bismillah",
                "In the name of Allah.",
                "Daily"
        ));

        list.add(new DuaModel(
                "After Eating",
                "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا",
                "Alhamdulillahil ladhi at'amana wa saqana",
                "All praise is to Allah who fed us and gave us drink.",
                "Daily"
        ));

        list.add(new DuaModel(
                "Before Sleeping",
                "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
                "Bismika Allahumma amutu wa ahya",
                "In Your name, O Allah, I die and I live.",
                "Night"
        ));

        list.add(new DuaModel(
                "Upon Waking Up",
                "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا",
                "Alhamdu lilahil ladhi ahyana",
                "All praise is to Allah who gave us life.",
                "Morning"
        ));

        list.add(new DuaModel(
                "Entering Mosque",
                "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ",
                "Allahummaf-tahli abwaba rahmatik",
                "O Allah, open the gates of Your mercy for me.",
                "Prayer"
        ));

        list.add(new DuaModel(
                "Dua for Parents",
                "رَّبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا",
                "Rabbir hamhuma kama rabbayani sagheera",
                "My Lord, have mercy on them as they raised me when I was young.",
                "Family"
        ));

        list.add(new DuaModel(
                "Dua for Forgiveness",
                "رَبَّنَا ظَلَمْنَا أَنفُسَنَا",
                "Rabbana zalamna anfusana",
                "Our Lord, we have wronged ourselves.",
                "Repentance"
        ));

        list.add(new DuaModel(
                "Istighfar",
                "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ",
                "Astaghfirullahal Azeem",
                "I seek forgiveness from Allah, the Almighty.",
                "Daily"
        ));

        list.add(new DuaModel(
                "Salawat (Durood)",
                "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ",
                "Allahumma salli ala Muhammad",
                "O Allah, send blessings upon Muhammad.",
                "Daily"
        ));

        list.add(new DuaModel(
                "Dua for Anxiety",
                "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ",
                "Allahumma inni a'udhu bika minal hammi wal hazan",
                "O Allah, I take refuge in You from anxiety and sorrow.",
                "Protection"
        ));

        list.add(new DuaModel(
                "Dua for Knowledge",
                "رَّبِّ زِدْنِي عِلْمًا",
                "Rabbi zidni ilma",
                "My Lord, increase me in knowledge.",
                "Daily"
        ));

        return list;
    }

    @Override
    public void onBackPressed() {
        adManager.showInterstitialAd(this, () ->
                runOnUiThread(super::onBackPressed)
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
