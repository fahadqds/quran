package com.nooralhuda.app.activities;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.nooralhuda.app.R;
import com.nooralhuda.app.databinding.ActivityQuranReaderBinding;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * QuranReaderActivity — Full 848-page Quran reader.
 *
 * Page images are stored as compressed JPEGs (480px, 70% quality) 
 * inside Parah zip files. Parah 1 is bundled in app assets.
 * Each page shows the actual 13-line colour-coded Tajweed Quran.
 *
 * Navigation: Prev/Next buttons + swipe gesture.
 * Bookmark and "I've read this" per page.
 * Pages cached in internal storage after first extraction.
 */
public class QuranReaderActivity extends AppCompatActivity {

    private ActivityQuranReaderBinding binding;
    private SharedPreferences prefs;
    private GestureDetector gestureDetector;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    private int currentPage = 1;
    static final int TOTAL_PAGES = 848;

    // Parah page boundaries (0-indexed: parah 1 = pages 1-28)
    private static final int[] PARAH_START = {
        1,29,57,85,113,141,169,197,225,253,
        281,309,337,365,393,421,449,477,505,533,
        561,589,617,645,673,701,729,757,785,813
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuranReaderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        prefs = getSharedPreferences("quran_prefs", MODE_PRIVATE);
        currentPage = getIntent().getIntExtra("page", prefs.getInt("last_page", 1));
        currentPage = Math.max(1, Math.min(currentPage, TOTAL_PAGES));

        setupGestures();
        setupButtons();
        // Extract Parah 1 on first run, then load current page
        ensureParahExtracted(getParahForPage(currentPage), () -> loadPage(currentPage));
    }

    /** Returns 1-indexed parah number for a given page */
    private int getParahForPage(int page) {
        for (int i = PARAH_START.length - 1; i >= 0; i--) {
            if (page >= PARAH_START[i]) return i + 1;
        }
        return 1;
    }

    /** Extracts parah zip from assets to internal storage if not already done */
    private void ensureParahExtracted(int parahNum, Runnable onDone) {
        File parahDir = getParahDir(parahNum);
        // Check if first page of parah already extracted
        String firstName = String.format("%03d.jpg", PARAH_START[parahNum - 1]);
        File firstPage = new File(parahDir, firstName);

        if (firstPage.exists()) {
            onDone.run();
            return;
        }

        // Show loading
        binding.pbPageLoading.setVisibility(View.VISIBLE);
        binding.ivQuranPage.setVisibility(View.INVISIBLE);

        executor.execute(() -> {
            try {
                extractParah(parahNum);
                mainHandler.post(onDone);
            } catch (Exception e) {
                mainHandler.post(() -> {
                    binding.pbPageLoading.setVisibility(View.GONE);
                    Toast.makeText(this, "Error loading Quran. Check internet.", Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    /** Extracts a parah zip from assets (parah 1) or downloads it */
    private void extractParah(int parahNum) throws IOException {
        File parahDir = getParahDir(parahNum);
        parahDir.mkdirs();

        String zipName = String.format("quran/parah_%02d.zip", parahNum);
        InputStream zipStream;

        // Try from assets first (Parah 1 is bundled)
        try {
            zipStream = getAssets().open(zipName);
        } catch (IOException e) {
            // Not in assets — should be downloaded
            // For now throw to show error; user would upload parahs to GitHub
            throw new IOException("Parah " + parahNum + " not in assets: " + e.getMessage());
        }

        // Extract all JPEGs from the zip
        try (ZipInputStream zis = new ZipInputStream(zipStream)) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.getName().endsWith(".jpg")) {
                    File outFile = new File(parahDir, entry.getName());
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        int len;
                        while ((len = zis.read(buffer)) > 0) {
                            fos.write(buffer, 0, len);
                        }
                    }
                }
                zis.closeEntry();
            }
        }
    }

    /** Returns the internal storage dir for a parah's extracted images */
    private File getParahDir(int parahNum) {
        return new File(getFilesDir(), String.format("quran/parah_%02d", parahNum));
    }

    /** Gets the JPEG file for a given Quran page number */
    private File getPageFile(int page) {
        int parah = getParahForPage(page);
        return new File(getParahDir(parah), String.format("%03d.jpg", page));
    }

    private void loadPage(int page) {
        prefs.edit().putInt("last_page", page).apply();
        binding.tvPageInfo.setText("Page " + page + " of " + TOTAL_PAGES);

        // Update nav buttons
        binding.btnPrevPage.setEnabled(page > 1);
        binding.btnNextPage.setEnabled(page < TOTAL_PAGES);
        binding.btnPrevPage.setAlpha(page > 1 ? 1f : 0.4f);
        binding.btnNextPage.setAlpha(page < TOTAL_PAGES ? 1f : 0.4f);

        // Sync bookmark
        Set<String> bookmarks = prefs.getStringSet("bookmarks", new HashSet<>());
        boolean bm = bookmarks.contains(String.valueOf(page));
        binding.btnBookmark.setColorFilter(getColor(bm ? R.color.gold_accent : R.color.text_secondary));

        // Sync checkbox silently
        binding.cbReadThis.setOnCheckedChangeListener(null);
        binding.cbReadThis.setChecked(prefs.getBoolean("read_" + page, false));
        binding.cbReadThis.setOnCheckedChangeListener((btn, checked) -> {
            if (checked) prefs.edit().putBoolean("read_" + page, true).apply();
        });

        // Load image from cached file
        File imgFile = getPageFile(page);
        if (imgFile.exists()) {
            binding.pbPageLoading.setVisibility(View.VISIBLE);
            binding.ivQuranPage.setVisibility(View.INVISIBLE);

            executor.execute(() -> {
                // Decode bitmap with inSampleSize for memory efficiency
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inPreferredConfig = Bitmap.Config.RGB_565; // saves 50% memory
                Bitmap bmp = BitmapFactory.decodeFile(imgFile.getAbsolutePath(), opts);
                mainHandler.post(() -> {
                    if (bmp != null && binding != null) {
                        binding.ivQuranPage.setImageBitmap(bmp);
                        binding.ivQuranPage.setVisibility(View.VISIBLE);
                        binding.pbPageLoading.setVisibility(View.GONE);
                    }
                });
            });
        } else {
            // Page file not extracted yet — ensure parah is extracted first
            ensureParahExtracted(getParahForPage(page), () -> loadPage(page));
        }
    }

    private void goToNextPage() {
        if (currentPage < TOTAL_PAGES) {
            currentPage++;
            int parah = getParahForPage(currentPage);
            ensureParahExtracted(parah, () -> loadPage(currentPage));
        }
    }

    private void goToPreviousPage() {
        if (currentPage > 1) {
            currentPage--;
            int parah = getParahForPage(currentPage);
            ensureParahExtracted(parah, () -> loadPage(currentPage));
        }
    }

    private void setupGestures() {
        gestureDetector = new GestureDetector(this,
            new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onFling(MotionEvent e1, MotionEvent e2, float vX, float vY) {
                    if (e1 == null || e2 == null) return false;
                    float dx = e2.getX() - e1.getX();
                    if (Math.abs(dx) > 80 && Math.abs(vX) > 100) {
                        if (dx < 0) goToNextPage(); else goToPreviousPage();
                        return true;
                    }
                    return false;
                }
            });
        binding.ivQuranPage.setOnTouchListener((v, e) -> {
            gestureDetector.onTouchEvent(e);
            return true;
        });
    }

    private void setupButtons() {
        binding.btnBack.setOnClickListener(v -> finish());
        binding.btnPrevPage.setOnClickListener(v -> goToPreviousPage());
        binding.btnNextPage.setOnClickListener(v -> goToNextPage());

        binding.btnBookmark.setOnClickListener(v -> {
            Set<String> bm = new HashSet<>(prefs.getStringSet("bookmarks", new HashSet<>()));
            String key = String.valueOf(currentPage);
            if (bm.contains(key)) {
                bm.remove(key);
                binding.btnBookmark.setColorFilter(getColor(R.color.text_secondary));
                Toast.makeText(this, "Bookmark removed", Toast.LENGTH_SHORT).show();
            } else {
                bm.add(key);
                binding.btnBookmark.setColorFilter(getColor(R.color.gold_accent));
                Toast.makeText(this, "✅ Page " + currentPage + " bookmarked!", Toast.LENGTH_SHORT).show();
            }
            prefs.edit().putStringSet("bookmarks", bm).apply();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
        binding = null;
    }
}
