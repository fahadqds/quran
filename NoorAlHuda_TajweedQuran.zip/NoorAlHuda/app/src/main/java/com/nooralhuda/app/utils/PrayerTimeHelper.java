package com.nooralhuda.app.utils;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PrayerTimeHelper - Fetches prayer times from Aladhan.com free API.
 * No API key required. Free and unlimited.
 * Falls back to Mecca coordinates if location unavailable.
 *
 * API: http://api.aladhan.com/v1/timingsByCity?city=Mecca&country=SA&method=2
 */
public class PrayerTimeHelper {

    private static final String TAG = "PrayerTimeHelper";

    // Default location: Mecca, Saudi Arabia
    private static final String DEFAULT_CITY    = "Mecca";
    private static final String DEFAULT_COUNTRY = "SA";

    // Aladhan API base URL
    private static final String BASE_URL =
            "http://api.aladhan.com/v1/timingsByCity?city=%s&country=%s&method=2";

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public PrayerTimeHelper(Context context) {
        this.context = context.getApplicationContext();
    }

    /**
     * Fetches prayer times asynchronously.
     * Results delivered via callback on a background thread
     * (caller must switch to UI thread).
     */
    public void fetchPrayerTimes(PrayerTimeCallback callback) {
        executor.execute(() -> {
            try {
                // Build API URL
                String urlStr = String.format(BASE_URL, DEFAULT_CITY, DEFAULT_COUNTRY);
                URL url = new URL(urlStr);

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);

                int responseCode = conn.getResponseCode();
                if (responseCode != 200) {
                    callback.onError("HTTP " + responseCode);
                    return;
                }

                // Read response
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();
                conn.disconnect();

                // Parse JSON
                JSONObject root    = new JSONObject(sb.toString());
                JSONObject data    = root.getJSONObject("data");
                JSONObject timings = data.getJSONObject("timings");

                PrayerTimes times = new PrayerTimes();
                times.fajr    = formatTime(timings.getString("Fajr"));
                times.dhuhr   = formatTime(timings.getString("Dhuhr"));
                times.asr     = formatTime(timings.getString("Asr"));
                times.maghrib = formatTime(timings.getString("Maghrib"));
                times.isha    = formatTime(timings.getString("Isha"));

                // Determine currently active prayer
                times.activePrayer = determineActivePrayer(times);

                callback.onSuccess(times);

            } catch (Exception e) {
                Log.e(TAG, "Prayer time fetch error: " + e.getMessage());
                callback.onError(e.getMessage());
            }
        });
    }

    /**
     * Formats time string from "HH:MM (timezone)" to "HH:MM AM/PM".
     */
    private String formatTime(String raw) {
        try {
            // Raw format is "04:32" (24hr) — convert to 12hr
            String[] parts = raw.trim().split(" ")[0].split(":");
            int hour   = Integer.parseInt(parts[0]);
            int minute = Integer.parseInt(parts[1]);
            String amPm = hour >= 12 ? "PM" : "AM";
            if (hour > 12) hour -= 12;
            if (hour == 0) hour = 12;
            return String.format("%d:%02d %s", hour, minute, amPm);
        } catch (Exception e) {
            return raw;
        }
    }

    /**
     * Determines which prayer is currently active based on device time.
     */
    private String determineActivePrayer(PrayerTimes times) {
        // Simple heuristic based on current hour
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);

        if (hour >= 4  && hour < 12) return "fajr";
        if (hour >= 12 && hour < 15) return "dhuhr";
        if (hour >= 15 && hour < 18) return "asr";
        if (hour >= 18 && hour < 20) return "maghrib";
        return "isha";
    }

    // ===================== Inner Classes =====================

    /**
     * Holds all five prayer times and the active prayer name.
     */
    public static class PrayerTimes {
        public String fajr;
        public String dhuhr;
        public String asr;
        public String maghrib;
        public String isha;
        public String activePrayer;
    }

    /**
     * Callback interface for async prayer time fetching.
     */
    public interface PrayerTimeCallback {
        void onSuccess(PrayerTimes times);
        void onError(String message);
    }
}
