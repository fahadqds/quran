package com.nooralhuda.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.nooralhuda.app.R;

import java.util.List;

/**
 * TemplateAdapter - Horizontal RecyclerView adapter for AI image prompt templates.
 */
public class TemplateAdapter extends RecyclerView.Adapter<TemplateAdapter.TemplateViewHolder> {

    private final List<String> templates;
    private final OnTemplateClickListener listener;

    public interface OnTemplateClickListener {
        void onTemplateClicked(String template);
    }

    public TemplateAdapter(List<String> templates, OnTemplateClickListener listener) {
        this.templates = templates;
        this.listener = listener;
    }

    @NonNull @Override
    public TemplateViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_template, parent, false);
        return new TemplateViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull TemplateViewHolder holder, int position) {
        String template = templates.get(position);

        // Show first 3 words as label
        String[] words = template.split(" ");
        String label = words.length >= 3
                ? words[0] + " " + words[1] + " " + words[2] + "..."
                : template;

        holder.tvTemplateLabel.setText(label);
        holder.itemView.setOnClickListener(v -> {
            // Scale animation
            v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(80)
                    .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()).start();
            listener.onTemplateClicked(template);
        });
    }

    @Override
    public int getItemCount() { return templates.size(); }

    static class TemplateViewHolder extends RecyclerView.ViewHolder {
        TextView tvTemplateLabel;
        TemplateViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTemplateLabel = itemView.findViewById(R.id.tv_template_label);
        }
    }
}
