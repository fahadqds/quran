package com.nooralhuda.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.nooralhuda.app.R;
import com.nooralhuda.app.models.DuaModel;

import java.util.List;

/**
 * DuaAdapter - RecyclerView adapter for Dua & Azkar list.
 */
public class DuaAdapter extends RecyclerView.Adapter<DuaAdapter.DuaViewHolder> {

    private final List<DuaModel> duas;

    public DuaAdapter(List<DuaModel> duas) {
        this.duas = duas;
    }

    @NonNull @Override
    public DuaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_dua, parent, false);
        return new DuaViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull DuaViewHolder holder, int position) {
        DuaModel dua = duas.get(position);
        holder.tvTitle.setText(dua.getTitle());
        holder.tvArabic.setText(dua.getArabicText());
        holder.tvTranslit.setText(dua.getTransliteration());
        holder.tvTranslation.setText(dua.getTranslation());
        holder.tvCategory.setText(dua.getCategory());

        // Expand/collapse on click
        holder.itemView.setOnClickListener(v -> {
            boolean isExpanded = holder.tvTranslit.getVisibility() == View.VISIBLE;
            holder.tvTranslit.setVisibility(isExpanded ? View.GONE : View.VISIBLE);
            holder.tvTranslation.setVisibility(isExpanded ? View.GONE : View.VISIBLE);
        });
    }

    @Override
    public int getItemCount() { return duas.size(); }

    static class DuaViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvArabic, tvTranslit, tvTranslation, tvCategory;

        DuaViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle       = itemView.findViewById(R.id.tv_dua_title);
            tvArabic      = itemView.findViewById(R.id.tv_dua_arabic);
            tvTranslit    = itemView.findViewById(R.id.tv_dua_translit);
            tvTranslation = itemView.findViewById(R.id.tv_dua_translation);
            tvCategory    = itemView.findViewById(R.id.tv_dua_category);
        }
    }
}
