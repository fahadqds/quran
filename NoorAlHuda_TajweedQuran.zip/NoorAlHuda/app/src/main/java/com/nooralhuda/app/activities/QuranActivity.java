package com.nooralhuda.app.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.nooralhuda.app.R;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.ActivityQuranBinding;

import java.util.HashSet;

/**
 * QuranActivity — Quran Home screen matching design images 7 & 8.
 * Buttons: Start Reading, Continue Reading, Bookmarks, Parah, Surah,
 *          Manzil, Sajdah, Download, Prayer Times, Qibla, Ad-Free, Rate Us.
 */
public class QuranActivity extends AppCompatActivity {

    private ActivityQuranBinding binding;
    private AdManager adManager;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuranBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        adManager = AdManager.getInstance();
        adManager.loadBannerAd(this, binding.adBannerContainer);
        adManager.loadInterstitialAd(this);
        adManager.loadRewardedAd(this);

        prefs = getSharedPreferences("quran_prefs", MODE_PRIVATE);

        setupButtons();
        binding.btnBack.setOnClickListener(v -> onBackPressed());
    }

    private void setupButtons() {
        // Start Reading
        binding.btnStartReading.setOnClickListener(v -> {
            animateBtn(v);
            adManager.showInterstitialAd(this, () -> runOnUiThread(() -> openSelection(0)));
        });
        // Continue Reading
        binding.btnContinueReading.setOnClickListener(v -> {
            animateBtn(v);
            int lastPage = prefs.getInt("last_page", 2);
            adManager.showInterstitialAd(this, () -> runOnUiThread(() -> {
                Intent i = new Intent(this, QuranReaderActivity.class);
                i.putExtra("page", lastPage);
                startActivity(i);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }));
        });
        // Bookmarks
        binding.btnBookmarks.setOnClickListener(v -> {
            animateBtn(v);
            java.util.Set<String> bm = prefs.getStringSet("bookmarks", new HashSet<>());
            if (bm.isEmpty()) {
                Toast.makeText(this, "No bookmarks yet. Bookmark pages while reading.",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            int firstBookmark = Integer.parseInt(bm.iterator().next());
            adManager.showInterstitialAd(this, () -> runOnUiThread(() -> {
                Intent i = new Intent(this, QuranReaderActivity.class);
                i.putExtra("page", firstBookmark);
                startActivity(i);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }));
        });
        // Parah
        binding.btnParah.setOnClickListener(v -> { animateBtn(v); adManager.showInterstitialAd(this, () -> runOnUiThread(() -> openSelection(0))); });
        // Surah
        binding.btnSurah.setOnClickListener(v -> { animateBtn(v); adManager.showInterstitialAd(this, () -> runOnUiThread(() -> openSelection(1))); });
        // Manzil
        binding.btnManzil.setOnClickListener(v -> { animateBtn(v); adManager.showInterstitialAd(this, () -> runOnUiThread(() -> openSelection(2))); });
        // Sajdah
        binding.btnSajdah.setOnClickListener(v -> { animateBtn(v); adManager.showInterstitialAd(this, () -> runOnUiThread(() -> openSelection(3))); });
        // Download
        binding.btnDownload.setOnClickListener(v -> {
            animateBtn(v);
            new AlertDialog.Builder(this)
                    .setTitle("📥 Download Quran Pages")
                    .setMessage("Quran pages load from the internet (Taj Company Mushaf).\n\nGlide caches pages automatically for offline use after first load.")
                    .setPositiveButton("OK", null).show();
        });
        // Prayer Times
        binding.btnPrayerTimes.setOnClickListener(v -> { animateBtn(v); finish(); });
        // Qibla
        binding.btnQiblaDirection.setOnClickListener(v -> {
            animateBtn(v);
            new AlertDialog.Builder(this)
                    .setTitle("🕌 Qibla Direction")
                    .setMessage("The Qibla points toward the Kaaba in Mecca, Saudi Arabia.\nUse a compass and face the calculated direction. May Allah accept your prayers. 🤲")
                    .setPositiveButton("OK", null).show();
        });
        // Ad-Free (Rewarded)
        binding.btnAdFree.setOnClickListener(v -> {
            animateBtn(v);
            adManager.showRewardedAd(this,
                    () -> runOnUiThread(() -> Toast.makeText(this, "🌟 Ad-free session active!", Toast.LENGTH_LONG).show()),
                    () -> {});
        });
        // Rate Us
        binding.btnRateUs.setOnClickListener(v -> {
            animateBtn(v);
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        android.net.Uri.parse("market://details?id=" + getPackageName())));
            } catch (Exception e) {
                Toast.makeText(this, "Rate us on Play Store!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openSelection(int tab) {
        Intent i = new Intent(this, QuranSelectionActivity.class);
        i.putExtra("tab", tab);
        startActivity(i);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void animateBtn(View v) {
        v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90)
                .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()).start();
    }

    @Override
    public void onBackPressed() {
        adManager.showInterstitialAd(this, () -> runOnUiThread(super::onBackPressed));
    }

    @Override protected void onDestroy() { super.onDestroy(); binding = null; }
}
