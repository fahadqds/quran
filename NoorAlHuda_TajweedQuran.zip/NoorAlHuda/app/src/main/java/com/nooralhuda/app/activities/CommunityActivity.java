package com.nooralhuda.app.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.ActivityCommunityBinding;

public class CommunityActivity extends AppCompatActivity {
    private ActivityCommunityBinding binding;
    private AdManager adManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCommunityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        adManager = AdManager.getInstance();
        adManager.loadBannerAd(this, binding.adBannerContainer);
        binding.btnBack.setOnClickListener(v -> onBackPressed());
    }

    @Override
    public void onBackPressed() {
        adManager.showInterstitialAd(this, () -> runOnUiThread(super::onBackPressed));
    }

    @Override protected void onDestroy() { super.onDestroy(); binding = null; }
}
