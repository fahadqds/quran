package com.nooralhuda.app.activities;

import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.ActivityTasbihBinding;

/**
 * TasbihActivity - Digital Tasbih / Dhikr counter screen.
 * Features:
 * - Large circular progress counter (0–99)
 * - Arabic dhikr text display
 * - Animated "+" button with vibration + sound
 * - Reset button with confirmation dialog
 * - Saves count using SharedPreferences
 * - Multiple dhikr presets (SubhanAllah, Alhamdulillah, AllahuAkbar)
 * - Banner Ad above bottom area
 */
public class TasbihActivity extends AppCompatActivity {

    // ViewBinding
    private ActivityTasbihBinding binding;

    // SharedPreferences keys
    private static final String PREFS_NAME = "tasbih_prefs";
    private static final String KEY_COUNT  = "tasbih_count";
    private static final String KEY_DHIKR  = "tasbih_dhikr_index";

    // Current dhikr counter
    private int count = 0;

    // Max count per round
    private static final int MAX_COUNT = 99;

    // Currently selected dhikr index
    private int dhikrIndex = 0;

    // Dhikr options
    private final String[] dhikrArabic  = {"سُبْحَانَ اللَّهِ", "الْحَمْدُ لِلَّهِ", "اللَّهُ أَكْبَرُ"};
    private final String[] dhikrEnglish = {"SubhanAllah", "Alhamdulillah", "Allahu Akbar"};
    private final String[] dhikrMeaning = {"Glory be to Allah", "All praise to Allah", "Allah is the Greatest"};

    // Vibrator
    private Vibrator vibrator;

    // Tone generator for click sound
    private ToneGenerator toneGen;

    // SharedPreferences
    private SharedPreferences prefs;

    // AdManager
    private AdManager adManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityTasbihBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        toneGen = new ToneGenerator(AudioManager.STREAM_MUSIC, 80);
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        adManager = AdManager.getInstance();

        // Load banner ad
        adManager.loadBannerAd(this, binding.adBannerContainer);

        // Pre-load interstitial
        adManager.loadInterstitialAd(this);

        // Restore saved state
        restoreState();

        // Setup UI
        updateDhikrDisplay();
        updateCountDisplay();

        // Setup click listeners
        setupClickListeners();

        // Back button
        binding.btnBack.setOnClickListener(v -> onBackPressed());
    }

    /**
     * Restores count and dhikr selection from SharedPreferences.
     */
    private void restoreState() {
        count = prefs.getInt(KEY_COUNT, 0);
        dhikrIndex = prefs.getInt(KEY_DHIKR, 0);
    }

    /**
     * Saves current count and dhikr selection to SharedPreferences.
     */
    private void saveState() {
        prefs.edit()
                .putInt(KEY_COUNT, count)
                .putInt(KEY_DHIKR, dhikrIndex)
                .apply();
    }

    /**
     * Updates the circular progress and count text.
     */
    private void updateCountDisplay() {
        // Update counter text
        binding.tvCount.setText(String.valueOf(count));

        // Update circular progress (0–99 mapped to 0–360 degrees)
        int progress = (int) ((count / (float) MAX_COUNT) * 100);
        binding.circularProgress.setProgress(progress);
    }

    /**
     * Updates the Arabic dhikr text, English name, and meaning.
     */
    private void updateDhikrDisplay() {
        binding.tvArabicDhikr.setText(dhikrArabic[dhikrIndex]);
        binding.tvDhikrName.setText(dhikrEnglish[dhikrIndex]);
        binding.tvDhikrMeaning.setText(dhikrMeaning[dhikrIndex]);
    }

    /**
     * Sets up all button click listeners.
     */
    private void setupClickListeners() {
        // "+" Count button
        binding.btnCount.setOnClickListener(v -> {
            incrementCount();
        });

        // Reset button
        binding.btnReset.setOnClickListener(v -> {
            animateButtonPress(v);
            showResetConfirmation();
        });

        // Dhikr selector chips
        binding.chipSubhanAllah.setOnClickListener(v -> {
            dhikrIndex = 0;
            updateDhikrDisplay();
            saveState();
        });

        binding.chipAlhamdulillah.setOnClickListener(v -> {
            dhikrIndex = 1;
            updateDhikrDisplay();
            saveState();
        });

        binding.chipAllahuAkbar.setOnClickListener(v -> {
            dhikrIndex = 2;
            updateDhikrDisplay();
            saveState();
        });
    }

    /**
     * Increments the counter, plays vibration + sound, animates button.
     */
    private void incrementCount() {
        if (count < MAX_COUNT) {
            count++;
        } else {
            // Round complete — reset and show congratulations
            count = 0;
            showRoundComplete();
        }

        // Animate the count button
        binding.btnCount.animate()
                .scaleX(0.90f).scaleY(0.90f).setDuration(80)
                .withEndAction(() ->
                        binding.btnCount.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                ).start();

        // Animate the count number
        binding.tvCount.animate()
                .scaleX(1.2f).scaleY(1.2f).setDuration(80)
                .withEndAction(() ->
                        binding.tvCount.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                ).start();

        // Vibrate (short pulse)
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE));
        }

        // Click sound
        try {
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 50);
        } catch (Exception ignored) {}

        // Update display
        updateCountDisplay();

        // Save state
        saveState();
    }

    /**
     * Shows a congratulations dialog when count reaches MAX_COUNT.
     */
    private void showRoundComplete() {
        new AlertDialog.Builder(this)
                .setTitle("🌟 MashaAllah!")
                .setMessage("You completed " + MAX_COUNT + " " + dhikrEnglish[dhikrIndex] + "!\n\n" +
                        "May Allah accept your dhikr. 🤲\n\nCounter has been reset.")
                .setPositiveButton("Continue", null)
                .show();
        updateCountDisplay();
    }

    /**
     * Shows a confirmation dialog before resetting the counter.
     */
    private void showResetConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Reset Counter?")
                .setMessage("Are you sure you want to reset the counter to 0?")
                .setPositiveButton("Reset", (dialog, which) -> {
                    count = 0;
                    updateCountDisplay();
                    saveState();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Scales a view down then up for a press effect.
     */
    private void animateButtonPress(View v) {
        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80)
                .withEndAction(() ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                ).start();
    }

    @Override
    public void onBackPressed() {
        saveState();
        adManager.showInterstitialAd(this, () ->
                runOnUiThread(super::onBackPressed)
        );
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveState();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (toneGen != null) toneGen.release();
        binding = null;
    }
}
