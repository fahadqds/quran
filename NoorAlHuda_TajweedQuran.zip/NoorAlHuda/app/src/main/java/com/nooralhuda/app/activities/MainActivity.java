package com.nooralhuda.app.activities;

import android.os.Bundle;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.nooralhuda.app.R;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.ActivityMainBinding;
import com.nooralhuda.app.fragments.HomeFragment;
import com.nooralhuda.app.fragments.CommunityFragment;
import com.nooralhuda.app.fragments.SettingsFragment;

/**
 * MainActivity — hosts BottomNavigationView + Fragment container.
 * Banner Ad sits above bottom nav.
 * Interstitial shown on every navigation item tap.
 */
public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private AdManager adManager;
    private int currentNavItemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        adManager = AdManager.getInstance();

        // Banner ad above bottom nav
        adManager.loadBannerAd(this, binding.adBannerContainer);

        // Pre-load interstitial
        adManager.loadInterstitialAd(this);

        // Setup bottom navigation
        setupBottomNavigation();

        // Load default: Home
        if (savedInstanceState == null) {
            loadFragment(new HomeFragment(), R.id.nav_home);
            binding.bottomNavigation.setSelectedItemId(R.id.nav_home);
        }
    }

    private void setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == currentNavItemId) return false;

            if (currentNavItemId == -1) {
                // First load — no ad
                navigateToTab(itemId);
            } else {
                adManager.showInterstitialAd(this, () ->
                        runOnUiThread(() -> navigateToTab(itemId)));
            }
            return true;
        });
    }

    private void navigateToTab(int itemId) {
        Fragment fragment;
        if (itemId == R.id.nav_home) {
            fragment = new HomeFragment();
        } else if (itemId == R.id.nav_community) {
            fragment = new CommunityFragment();
        } else if (itemId == R.id.nav_settings) {
            fragment = new SettingsFragment();
        } else {
            return;
        }
        loadFragment(fragment, itemId);
    }

    private void loadFragment(Fragment fragment, int itemId) {
        currentNavItemId = itemId;
        getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(
                        R.anim.slide_in_right, R.anim.slide_out_left,
                        R.anim.slide_in_left, R.anim.slide_out_right)
                .replace(R.id.fragmentContainer, fragment)
                .commit();
    }

    @Override
    public void onBackPressed() {
        if (currentNavItemId != R.id.nav_home) {
            binding.bottomNavigation.setSelectedItemId(R.id.nav_home);
        } else {
            adManager.showInterstitialAd(this, () -> runOnUiThread(super::onBackPressed));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
