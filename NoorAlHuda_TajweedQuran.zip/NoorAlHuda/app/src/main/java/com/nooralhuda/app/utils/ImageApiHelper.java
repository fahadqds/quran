package com.nooralhuda.app.utils;

import android.util.Log;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ImageApiHelper - Generates AI images using Pollinations.ai free API.
 *
 * Pollinations.ai is completely FREE, no API key required, unlimited requests.
 * URL format: https://image.pollinations.ai/prompt/{encoded_prompt}?width=512&height=512
 *
 * Simply building the URL IS the "API call" — Pollinations serves the image directly.
 */
public class ImageApiHelper {

    private static final String TAG = "ImageApiHelper";

    // Pollinations.ai endpoint — no auth needed, totally free
    private static final String BASE_URL = "https://image.pollinations.ai/prompt/%s?width=512&height=512&nologo=true";

    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    /**
     * Generates an AI image URL from a text prompt.
     * The URL itself serves as the image — load it with Glide directly.
     *
     * @param prompt   Text description of the desired image
     * @param callback Delivers the image URL or an error message
     */
    public static void generateImage(String prompt, ImageCallback callback) {
        executor.execute(() -> {
            try {
                // URL-encode the prompt
                String encoded = URLEncoder.encode(prompt, StandardCharsets.UTF_8.toString());

                // Build the full image URL
                String imageUrl = String.format(BASE_URL, encoded);

                Log.d(TAG, "Generated image URL: " + imageUrl);

                // Deliver URL — Glide will fetch the actual image
                callback.onSuccess(imageUrl);

            } catch (Exception e) {
                Log.e(TAG, "ImageApi error: " + e.getMessage());
                callback.onError("Failed to build image URL: " + e.getMessage());
            }
        });
    }

    /**
     * Callback interface for image generation.
     */
    public interface ImageCallback {
        void onSuccess(String imageUrl);
        void onError(String error);
    }
}
