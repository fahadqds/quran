package com.nooralhuda.app.activities;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.ActivityAdhanBinding;

public class AdhanActivity extends AppCompatActivity {
    private ActivityAdhanBinding binding;
    private AdManager adManager;
    private MediaPlayer mediaPlayer;
    private boolean isPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAdhanBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        adManager = AdManager.getInstance();
        adManager.loadBannerAd(this, binding.adBannerContainer);
        adManager.loadInterstitialAd(this);
        binding.btnPlayAdhan.setOnClickListener(v -> { animateButton(v); toggleAdhan(); });
        binding.btnBack.setOnClickListener(v -> onBackPressed());
    }

    private void toggleAdhan() {
        if (isPlaying) stopAdhan(); else playAdhan();
    }

    private void playAdhan() {
        try {
            if (mediaPlayer != null) mediaPlayer.release();
            // Requires adhan_placeholder.mp3 in res/raw/
            int resId = getResources().getIdentifier("adhan_placeholder", "raw", getPackageName());
            if (resId == 0) {
                Toast.makeText(this, "Add adhan_placeholder.mp3 to res/raw/ folder", Toast.LENGTH_LONG).show();
                return;
            }
            mediaPlayer = MediaPlayer.create(this, resId);
            if (mediaPlayer != null) {
                mediaPlayer.start();
                mediaPlayer.setOnCompletionListener(mp -> stopAdhan());
                isPlaying = true;
                binding.btnPlayAdhan.setText("⏸ Pause Adhan");
            }
        } catch (Exception e) {
            Toast.makeText(this, "Could not play Adhan audio.", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopAdhan() {
        if (mediaPlayer != null) { mediaPlayer.stop(); mediaPlayer.release(); mediaPlayer = null; }
        isPlaying = false;
        if (binding != null) binding.btnPlayAdhan.setText("▶ Play Adhan");
    }

    private void animateButton(View v) {
        v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(100)
                .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()).start();
    }

    @Override
    public void onBackPressed() {
        stopAdhan();
        adManager.showInterstitialAd(this, () -> runOnUiThread(super::onBackPressed));
    }

    @Override protected void onDestroy() { super.onDestroy(); stopAdhan(); binding = null; }
}
