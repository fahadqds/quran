package com.nooralhuda.app.fragments;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.*;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.nooralhuda.app.databinding.FragmentSettingsBinding;

import static android.content.Context.MODE_PRIVATE;

/**
 * SettingsFragment - Settings tab in bottom navigation.
 */
public class SettingsFragment extends Fragment {

    private FragmentSettingsBinding binding;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentSettingsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SharedPreferences prefs = requireContext()
                .getSharedPreferences("app_prefs", MODE_PRIVATE);

        binding.switchNotifications.setChecked(prefs.getBoolean("notifications", true));
        binding.switchVibration.setChecked(prefs.getBoolean("vibration", true));
        binding.etUserName.setText(prefs.getString("user_name", "Ahmed"));

        binding.btnSave.setOnClickListener(v -> {
            prefs.edit()
                    .putBoolean("notifications", binding.switchNotifications.isChecked())
                    .putBoolean("vibration", binding.switchVibration.isChecked())
                    .putString("user_name", binding.etUserName.getText().toString().trim())
                    .apply();
            Toast.makeText(requireContext(), "✅ Settings saved!", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
