package com.nooralhuda.app.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.nooralhuda.app.R;
import com.nooralhuda.app.databinding.ActivityQuranSelectionBinding;
import com.nooralhuda.app.models.QuranData;
import com.nooralhuda.app.models.QuranData.QuranItem;

import java.util.List;

/**
 * QuranSelectionActivity — "Selection" screen.
 * Matches design images 3, 4, 5, 6:
 *   4 tabs: Parah (30), Surah (114), Manzil (7), Sajdah (14)
 *   Each row: progress %, number badge, name, page badge
 *   Tapping a row opens QuranReaderActivity at that page.
 */
public class QuranSelectionActivity extends AppCompatActivity {

    private ActivityQuranSelectionBinding binding;
    private SharedPreferences prefs;
    private int currentTab = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuranSelectionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        prefs = getSharedPreferences("quran_prefs", MODE_PRIVATE);
        currentTab = getIntent().getIntExtra("tab", 0);

        setupTabClicks();
        loadTab(currentTab);
        updateTabUI(currentTab);

        binding.btnBack.setOnClickListener(v -> finish());
    }

    private void setupTabClicks() {
        binding.tabParah.setOnClickListener(v  -> switchTab(0));
        binding.tabSurah.setOnClickListener(v  -> switchTab(1));
        binding.tabManzil.setOnClickListener(v -> switchTab(2));
        binding.tabSajdah.setOnClickListener(v -> switchTab(3));
    }

    private void switchTab(int tab) {
        currentTab = tab;
        updateTabUI(tab);
        loadTab(tab);
    }

    private void updateTabUI(int tab) {
        int activeColor  = getColor(R.color.emerald_medium);
        int defaultColor = getColor(R.color.text_muted);

        // Reset text colors
        binding.tabParah.setTextColor(defaultColor);
        binding.tabSurah.setTextColor(defaultColor);
        binding.tabManzil.setTextColor(defaultColor);
        binding.tabSajdah.setTextColor(defaultColor);

        // Hide all indicators
        binding.indicatorParah.setVisibility(View.INVISIBLE);
        binding.indicatorSurah.setVisibility(View.INVISIBLE);
        binding.indicatorManzil.setVisibility(View.INVISIBLE);
        binding.indicatorSajdah.setVisibility(View.INVISIBLE);

        // Activate selected tab
        switch (tab) {
            case 0: binding.tabParah.setTextColor(activeColor);  binding.indicatorParah.setVisibility(View.VISIBLE);  break;
            case 1: binding.tabSurah.setTextColor(activeColor);  binding.indicatorSurah.setVisibility(View.VISIBLE);  break;
            case 2: binding.tabManzil.setTextColor(activeColor); binding.indicatorManzil.setVisibility(View.VISIBLE); break;
            case 3: binding.tabSajdah.setTextColor(activeColor); binding.indicatorSajdah.setVisibility(View.VISIBLE); break;
        }
    }

    private void loadTab(int tab) {
        List<QuranItem> items;
        boolean showHeader; // "Read | Name | Page" header row (not shown for Surah)

        switch (tab) {
            case 1:  items = QuranData.getSurahs();  showHeader = false; break;
            case 2:  items = QuranData.getManzils(); showHeader = true;  break;
            case 3:  items = QuranData.getSajdahs(); showHeader = true;  break;
            default: items = QuranData.getParahs();  showHeader = true;  break;
        }

        binding.headerRow.setVisibility(showHeader ? View.VISIBLE : View.GONE);

        QuranListAdapter adapter = new QuranListAdapter(items, tab, item -> {
            prefs.edit().putInt("last_page", item.page).apply();
            Intent intent = new Intent(this, QuranReaderActivity.class);
            intent.putExtra("page", item.page);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        binding.rvQuranList.setLayoutManager(new LinearLayoutManager(this));
        binding.rvQuranList.setAdapter(adapter);
    }

    // ===================== Inner RecyclerView Adapter =====================
    public static class QuranListAdapter extends RecyclerView.Adapter<QuranListAdapter.VH> {

        private final List<QuranItem> items;
        private final int tabType;
        private final OnItemClick listener;

        interface OnItemClick { void onClick(QuranItem item); }

        QuranListAdapter(List<QuranItem> items, int tabType, OnItemClick listener) {
            this.items   = items;
            this.tabType = tabType;
            this.listener = listener;
        }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_quran_list, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            QuranItem item = items.get(pos);

            h.tvNumber.setText(String.valueOf(item.number));
            h.tvName.setText(item.name);
            h.tvPage.setText(String.valueOf(item.page));
            h.tvProgress.setText("0%");

            // Surah uses dark badge (like the design image), others use light green
            if (tabType == 1) {
                h.tvNumber.setBackgroundResource(R.drawable.bg_surah_number_dark);
                h.tvNumber.setTextColor(h.itemView.getContext().getColor(R.color.white));
            } else {
                h.tvNumber.setBackgroundResource(R.drawable.bg_circle_emerald_light);
                h.tvNumber.setTextColor(h.itemView.getContext().getColor(R.color.emerald_medium));
            }

            h.itemView.setOnClickListener(v -> {
                v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80)
                        .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f)
                                .setDuration(80).start()).start();
                listener.onClick(item);
            });
        }

        @Override public int getItemCount() { return items.size(); }

        static class VH extends RecyclerView.ViewHolder {
            TextView tvNumber, tvName, tvPage, tvProgress;
            VH(@NonNull View v) {
                super(v);
                tvNumber   = v.findViewById(R.id.tv_item_number);
                tvName     = v.findViewById(R.id.tv_item_name);
                tvPage     = v.findViewById(R.id.tv_item_page);
                tvProgress = v.findViewById(R.id.tv_item_progress);
            }
        }
    }

    @Override protected void onDestroy() { super.onDestroy(); binding = null; }
}
