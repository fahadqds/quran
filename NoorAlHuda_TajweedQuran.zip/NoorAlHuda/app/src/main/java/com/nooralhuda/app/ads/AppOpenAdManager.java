package com.nooralhuda.app.ads;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

import java.util.Date;

/**
 * AppOpenAdManager - Manages App Open Ads.
 * Shows ads when app comes to foreground (cold start / background → foreground).
 * Implements DefaultLifecycleObserver to detect app foregrounding.
 * Implements ActivityLifecycleCallbacks to track current activity.
 */
public class AppOpenAdManager implements DefaultLifecycleObserver,
        Application.ActivityLifecycleCallbacks {

    private static final String TAG = "AppOpenAdManager";

    // Load timeout: ads expire after 4 hours
    private static final long AD_EXPIRY_MS = 4 * 60 * 60 * 1000;

    // Current loaded App Open Ad
    private AppOpenAd appOpenAd = null;

    // Whether an ad is currently being shown
    private boolean isShowingAd = false;

    // Timestamp when the ad was loaded
    private long loadTime = 0;

    // Reference to current foreground activity
    private Activity currentActivity;

    // Application context
    private final Application application;

    public AppOpenAdManager(Application application) {
        this.application = application;
        // Register to track activity lifecycle
        application.registerActivityLifecycleCallbacks(this);
    }

    /**
     * Pre-loads an App Open Ad.
     */
    public void loadAd() {
        // Don't load if already showing or already loaded
        if (isAdAvailable()) return;

        AdRequest adRequest = new AdRequest.Builder().build();
        AppOpenAd.load(application, AdManager.APP_OPEN_AD_UNIT_ID,
                adRequest, new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd ad) {
                        appOpenAd = ad;
                        loadTime = new Date().getTime();
                        Log.d(TAG, "App Open Ad loaded.");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        Log.e(TAG, "App Open Ad failed: " + loadAdError.getMessage());
                    }
                });
    }

    /**
     * Shows the App Open Ad if available and not already showing.
     */
    public void showAdIfAvailable() {
        // Don't show if already showing
        if (isShowingAd) return;

        // Don't show if no ad or ad expired
        if (!isAdAvailable()) {
            loadAd();
            return;
        }

        // Don't show if no current activity
        if (currentActivity == null) return;

        appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                // Ad was closed, reset and preload next
                appOpenAd = null;
                isShowingAd = false;
                loadAd();
                Log.d(TAG, "App Open Ad dismissed.");
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                isShowingAd = false;
                Log.e(TAG, "App Open Ad failed to show: " + adError.getMessage());
            }

            @Override
            public void onAdShowedFullScreenContent() {
                isShowingAd = true;
                Log.d(TAG, "App Open Ad showed.");
            }
        });

        isShowingAd = true;
        appOpenAd.show(currentActivity);
    }

    /**
     * Returns true if we have a non-expired ad ready to show.
     */
    private boolean isAdAvailable() {
        return appOpenAd != null && !wasLoadTimeLimitExceeded();
    }

    /**
     * Returns true if the ad was loaded more than 4 hours ago.
     */
    private boolean wasLoadTimeLimitExceeded() {
        return new Date().getTime() - loadTime > AD_EXPIRY_MS;
    }

    // ===================== Lifecycle Observer =====================

    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        // App came to foreground — show App Open Ad
        showAdIfAvailable();
    }

    // ===================== Activity Lifecycle Callbacks =====================

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {}

    @Override
    public void onActivityCreated(@NonNull Activity activity, Bundle savedInstanceState) {}

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {}

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {}

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        if (currentActivity == activity) currentActivity = null;
    }
}
