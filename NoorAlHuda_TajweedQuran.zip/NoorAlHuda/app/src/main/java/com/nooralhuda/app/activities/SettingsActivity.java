package com.nooralhuda.app.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.ActivitySettingsBinding;

public class SettingsActivity extends AppCompatActivity {
    private ActivitySettingsBinding binding;
    private AdManager adManager;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        adManager = AdManager.getInstance();
        adManager.loadBannerAd(this, binding.adBannerContainer);
        adManager.loadInterstitialAd(this);
        prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);

        binding.switchNotifications.setChecked(prefs.getBoolean("notifications", true));
        binding.switchVibration.setChecked(prefs.getBoolean("vibration", true));
        binding.etUserName.setText(prefs.getString("user_name", "Ahmed"));

        binding.btnSave.setOnClickListener(v -> {
            prefs.edit()
                    .putBoolean("notifications", binding.switchNotifications.isChecked())
                    .putBoolean("vibration", binding.switchVibration.isChecked())
                    .putString("user_name", binding.etUserName.getText().toString().trim())
                    .apply();
            Toast.makeText(this, "✅ Settings saved!", Toast.LENGTH_SHORT).show();
        });
        binding.btnBack.setOnClickListener(v -> onBackPressed());
    }

    @Override
    public void onBackPressed() {
        adManager.showInterstitialAd(this, () -> runOnUiThread(super::onBackPressed));
    }

    @Override protected void onDestroy() { super.onDestroy(); binding = null; }
}
