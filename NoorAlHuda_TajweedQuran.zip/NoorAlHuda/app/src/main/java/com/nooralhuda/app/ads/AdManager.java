package com.nooralhuda.app.ads;

import android.app.Activity;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import androidx.annotation.NonNull;

/**
 * AdManager - Centralized class for all AdMob ad types.
 * Handles: Banner Ads, Interstitial Ads, Rewarded Ads.
 * All IDs below are TEST IDs. Replace with real IDs before publishing.
 */
public class AdManager {

    private static final String TAG = "AdManager";

    // ==================== TEST AD UNIT IDs ====================
    // Replace these with your actual AdMob ad unit IDs before publishing
    public static final String BANNER_AD_UNIT_ID       = "ca-app-pub-3940256099942544/6300978111";
    public static final String INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712";
    public static final String REWARDED_AD_UNIT_ID     = "ca-app-pub-3940256099942544/5224354917";
    public static final String APP_OPEN_AD_UNIT_ID     = "ca-app-pub-3940256099942544/9257395921";
    // ==========================================================

    // Interstitial ad instance
    private InterstitialAd mInterstitialAd;

    // Rewarded ad instance
    private RewardedAd mRewardedAd;

    // Singleton instance
    private static AdManager instance;

    // Private constructor for singleton
    private AdManager() {}

    /**
     * Returns singleton AdManager instance.
     */
    public static synchronized AdManager getInstance() {
        if (instance == null) {
            instance = new AdManager();
        }
        return instance;
    }

    // ===================== BANNER AD =====================

    /**
     * Loads and shows a Banner Ad in the given container (FrameLayout).
     * Place container above bottom navigation bar in your layout XML.
     *
     * @param activity  The hosting activity
     * @param container The FrameLayout/ViewGroup to hold the banner
     */
    public void loadBannerAd(Activity activity, FrameLayout container) {
        if (activity == null || container == null) return;

        // Create AdView
        AdView adView = new AdView(activity);
        adView.setAdUnitId(BANNER_AD_UNIT_ID);
        adView.setAdSize(AdSize.BANNER);

        // Add to container
        container.removeAllViews();
        container.addView(adView);

        // Set listener
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                Log.d(TAG, "Banner Ad loaded.");
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                Log.e(TAG, "Banner Ad failed: " + adError.getMessage());
            }
        });

        // Load the ad
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    // ===================== INTERSTITIAL AD =====================

    /**
     * Pre-loads an Interstitial Ad. Call this early (e.g., in onCreate).
     * After loading, call showInterstitialAd() to display it.
     *
     * @param activity The hosting activity
     */
    public void loadInterstitialAd(Activity activity) {
        if (activity == null) return;

        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(activity, INTERSTITIAL_AD_UNIT_ID, adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        Log.d(TAG, "Interstitial Ad loaded.");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                        mInterstitialAd = null;
                        Log.e(TAG, "Interstitial Ad failed: " + adError.getMessage());
                    }
                });
    }

    /**
     * Shows the pre-loaded Interstitial Ad.
     * Reloads the next ad after the current one is dismissed.
     * Executes the onAdDismissed runnable after showing (or immediately if no ad).
     *
     * @param activity         The hosting activity
     * @param onAdDismissed    Runnable to execute after ad is dismissed/not shown
     */
    public void showInterstitialAd(Activity activity, Runnable onAdDismissed) {
        if (mInterstitialAd != null && activity != null) {
            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Interstitial dismissed.");
                    mInterstitialAd = null;
                    // Reload for next use
                    loadInterstitialAd(activity);
                    // Execute action after ad
                    if (onAdDismissed != null) onAdDismissed.run();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                    Log.e(TAG, "Interstitial failed to show: " + adError.getMessage());
                    mInterstitialAd = null;
                    if (onAdDismissed != null) onAdDismissed.run();
                }
            });
            mInterstitialAd.show(activity);
        } else {
            Log.d(TAG, "No Interstitial Ad ready, executing action directly.");
            if (onAdDismissed != null) onAdDismissed.run();
        }
    }

    // ===================== REWARDED AD =====================

    /**
     * Pre-loads a Rewarded Ad.
     *
     * @param activity The hosting activity
     */
    public void loadRewardedAd(Activity activity) {
        if (activity == null) return;

        AdRequest adRequest = new AdRequest.Builder().build();
        RewardedAd.load(activity, REWARDED_AD_UNIT_ID, adRequest,
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                        mRewardedAd = rewardedAd;
                        Log.d(TAG, "Rewarded Ad loaded.");
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                        mRewardedAd = null;
                        Log.e(TAG, "Rewarded Ad failed: " + adError.getMessage());
                    }
                });
    }

    /**
     * Shows the pre-loaded Rewarded Ad.
     *
     * @param activity        The hosting activity
     * @param onRewarded      Runnable executed when user earns reward
     * @param onAdDismissed   Runnable executed when ad is dismissed without reward
     */
    public void showRewardedAd(Activity activity, Runnable onRewarded, Runnable onAdDismissed) {
        if (mRewardedAd != null && activity != null) {
            mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Rewarded Ad dismissed.");
                    mRewardedAd = null;
                    loadRewardedAd(activity);
                    if (onAdDismissed != null) onAdDismissed.run();
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                    Log.e(TAG, "Rewarded Ad failed to show.");
                    mRewardedAd = null;
                    if (onAdDismissed != null) onAdDismissed.run();
                }
            });

            mRewardedAd.show(activity, rewardItem -> {
                Log.d(TAG, "User earned reward: " + rewardItem.getAmount() + " " + rewardItem.getType());
                if (onRewarded != null) onRewarded.run();
            });
        } else {
            Log.d(TAG, "No Rewarded Ad ready.");
            // Give reward anyway (graceful fallback)
            if (onRewarded != null) onRewarded.run();
        }
    }

    /**
     * Returns true if a rewarded ad is ready to show.
     */
    public boolean isRewardedAdReady() {
        return mRewardedAd != null;
    }

    /**
     * Returns true if an interstitial ad is ready to show.
     */
    public boolean isInterstitialAdReady() {
        return mInterstitialAd != null;
    }
}
