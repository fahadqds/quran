package com.nooralhuda.app.activities;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.nooralhuda.app.R;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.databinding.ActivityZakatBinding;

/**
 * ZakatActivity — Zakat Calculator.
 * Calculates 2.5% zakat on wealth above Nisab threshold.
 */
public class ZakatActivity extends AppCompatActivity {

    private ActivityZakatBinding binding;
    private AdManager adManager;

    private static final double NISAB_THRESHOLD_USD = 5500.0;
    private static final double ZAKAT_RATE = 0.025;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityZakatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        adManager = AdManager.getInstance();
        adManager.loadBannerAd(this, binding.adBannerContainer);
        adManager.loadInterstitialAd(this);

        binding.tvNisabValue.setText(String.format("Nisab Threshold: $%.2f", NISAB_THRESHOLD_USD));

        setupTextWatchers();

        binding.btnCalculate.setOnClickListener(v -> {
            animateButton(v);
            calculateZakat();
        });

        binding.btnReset.setOnClickListener(v -> clearAll());
        binding.btnBack.setOnClickListener(v -> onBackPressed());
    }

    private void setupTextWatchers() {
        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) { calculateZakat(); }
        };
        binding.etCash.addTextChangedListener(watcher);
        binding.etGoldValue.addTextChangedListener(watcher);
        binding.etSilverValue.addTextChangedListener(watcher);
        binding.etStocks.addTextChangedListener(watcher);
        binding.etBusinessAssets.addTextChangedListener(watcher);
        binding.etDebts.addTextChangedListener(watcher);
    }

    private void calculateZakat() {
        double cash           = parseDouble(binding.etCash.getText().toString());
        double gold           = parseDouble(binding.etGoldValue.getText().toString());
        double silver         = parseDouble(binding.etSilverValue.getText().toString());
        double stocks         = parseDouble(binding.etStocks.getText().toString());
        double businessAssets = parseDouble(binding.etBusinessAssets.getText().toString());
        double debts          = parseDouble(binding.etDebts.getText().toString());

        double totalWealth = Math.max(0, cash + gold + silver + stocks + businessAssets - debts);

        binding.cardResult.setVisibility(View.VISIBLE);
        binding.tvTotalWealth.setText(String.format("$%.2f", totalWealth));

        if (totalWealth < NISAB_THRESHOLD_USD) {
            binding.tvZakatAmount.setText("$0.00");
            binding.tvZakatStatus.setText("⚠️ Below Nisab — Zakat not obligatory");
            binding.tvZakatStatus.setTextColor(getColor(R.color.gold_accent));
        } else {
            double zakatAmount = totalWealth * ZAKAT_RATE;
            binding.tvZakatAmount.setText(String.format("$%.2f", zakatAmount));
            binding.tvZakatStatus.setText("✅ Zakat is obligatory (2.5%)");
            binding.tvZakatStatus.setTextColor(getColor(R.color.emerald_light));
        }
    }

    private double parseDouble(String s) {
        try {
            return (s == null || s.trim().isEmpty()) ? 0 : Double.parseDouble(s.trim());
        } catch (NumberFormatException e) { return 0; }
    }

    private void clearAll() {
        binding.etCash.setText("");
        binding.etGoldValue.setText("");
        binding.etSilverValue.setText("");
        binding.etStocks.setText("");
        binding.etBusinessAssets.setText("");
        binding.etDebts.setText("");
        binding.cardResult.setVisibility(View.GONE);
    }

    private void animateButton(View v) {
        v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(100)
                .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()).start();
    }

    @Override
    public void onBackPressed() {
        adManager.showInterstitialAd(this, () -> runOnUiThread(() -> {
            super.onBackPressed();
        }));
    }

    @Override protected void onDestroy() { super.onDestroy(); binding = null; }
}
