package com.nooralhuda.app.models;

/**
 * DuaModel - Data model for a single Dua (supplication).
 */
public class DuaModel {
    private String title;
    private String arabicText;
    private String transliteration;
    private String translation;
    private String category;

    public DuaModel(String title, String arabicText, String transliteration,
                    String translation, String category) {
        this.title = title;
        this.arabicText = arabicText;
        this.transliteration = transliteration;
        this.translation = translation;
        this.category = category;
    }

    public String getTitle()           { return title; }
    public String getArabicText()      { return arabicText; }
    public String getTransliteration() { return transliteration; }
    public String getTranslation()     { return translation; }
    public String getCategory()        { return category; }
}
