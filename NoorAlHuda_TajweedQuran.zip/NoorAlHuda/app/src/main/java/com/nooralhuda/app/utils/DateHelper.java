package com.nooralhuda.app.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * DateHelper - Utility for formatting dates.
 */
public class DateHelper {

    /**
     * Returns current date formatted as "EEEE, MMM d, yyyy".
     * Example: "Tuesday, Apr 22, 2025"
     */
    public static String getCurrentFormattedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE, MMM d, yyyy", Locale.getDefault());
        return sdf.format(new Date());
    }

    /**
     * Returns current Hijri date label (approximate — placeholder).
     * For exact Hijri conversion, integrate a dedicated library.
     */
    public static String getCurrentHijriDate() {
        return ""; // Placeholder — can integrate UmAlQura calendar lib
    }
}
