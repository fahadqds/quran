package com.nooralhuda.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;

import androidx.appcompat.app.AppCompatActivity;

import com.nooralhuda.app.MyApplication;
import com.nooralhuda.app.databinding.ActivitySplashBinding;

/**
 * SplashActivity - First screen shown on app launch.
 * Shows animated mosque logo, app name, and loading text.
 * Displays App Open Ad, then navigates to MainActivity after 3 seconds.
 */
public class SplashActivity extends AppCompatActivity {

    // ViewBinding instance
    private ActivitySplashBinding binding;

    // Delay in milliseconds before navigating to home
    private static final long SPLASH_DELAY = 3000;

    // Handler for delayed navigation
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflate layout using ViewBinding
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Start logo entrance animation
        startLogoAnimation();

        // Start app name fade-in animation
        startAppNameAnimation();

        // Start loading text animation
        startLoadingAnimation();

        // Navigate to MainActivity after delay
        handler.postDelayed(this::navigateToMain, SPLASH_DELAY);
    }

    /**
     * Animates the mosque logo with scale + glow effect.
     */
    private void startLogoAnimation() {
        // Scale animation: grow from 0.5 to 1.0
        ScaleAnimation scaleAnim = new ScaleAnimation(
                0.5f, 1.0f,
                0.5f, 1.0f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        scaleAnim.setDuration(1200);
        scaleAnim.setFillAfter(true);

        // Alpha animation: fade in
        AlphaAnimation alphaAnim = new AlphaAnimation(0f, 1f);
        alphaAnim.setDuration(1200);
        alphaAnim.setFillAfter(true);

        // Combine animations
        AnimationSet animSet = new AnimationSet(false);
        animSet.addAnimation(scaleAnim);
        animSet.addAnimation(alphaAnim);

        binding.ivMosqueLogo.startAnimation(animSet);
    }

    /**
     * Fades in the Arabic + English app name text.
     */
    private void startAppNameAnimation() {
        // Delay 600ms then fade in
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setStartOffset(600);
        fadeIn.setDuration(800);
        fadeIn.setFillAfter(true);

        // Slight upward slide
        TranslateAnimation slideUp = new TranslateAnimation(0, 0, 50f, 0f);
        slideUp.setStartOffset(600);
        slideUp.setDuration(800);
        slideUp.setFillAfter(true);

        AnimationSet nameAnim = new AnimationSet(false);
        nameAnim.addAnimation(fadeIn);
        nameAnim.addAnimation(slideUp);

        binding.tvArabicName.startAnimation(nameAnim);
        binding.tvAppName.startAnimation(nameAnim);
    }

    /**
     * Fades in loading text with a pulsing effect.
     */
    private void startLoadingAnimation() {
        AlphaAnimation pulse = new AlphaAnimation(0.3f, 1f);
        pulse.setStartOffset(1200);
        pulse.setDuration(600);
        pulse.setRepeatMode(Animation.REVERSE);
        pulse.setRepeatCount(Animation.INFINITE);

        binding.tvLoading.startAnimation(pulse);
    }

    /**
     * Navigates to MainActivity and finishes Splash.
     */
    private void navigateToMain() {
        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
        startActivity(intent);
        // Custom transition animation
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove pending callbacks to prevent memory leaks
        handler.removeCallbacksAndMessages(null);
        binding = null;
    }
}
