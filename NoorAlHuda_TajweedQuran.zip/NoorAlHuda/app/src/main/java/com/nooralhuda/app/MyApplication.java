package com.nooralhuda.app;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.MobileAds;
import com.nooralhuda.app.ads.AdManager;
import com.nooralhuda.app.ads.AppOpenAdManager;

/**
 * MyApplication - Application class for Noor Al-Huda.
 * Handles global initialization: AdMob, App Open Ads lifecycle.
 * Must be registered in AndroidManifest.xml as android:name=".MyApplication"
 */
public class MyApplication extends Application {

    private static final String TAG = "MyApplication";

    // Singleton instance
    private static MyApplication instance;

    // App Open Ad Manager
    private AppOpenAdManager appOpenAdManager;

    @Override
    public void onCreate() {
        super.onCreate();

        // Store singleton reference
        instance = this;

        // Initialize Google Mobile Ads SDK
        MobileAds.initialize(this, initializationStatus -> {
            Log.d(TAG, "AdMob SDK initialized successfully.");
        });

        // Initialize AppOpen Ad Manager and observe lifecycle
        appOpenAdManager = new AppOpenAdManager(this);

        // Register lifecycle observer to show App Open Ad on foreground
        ProcessLifecycleOwner.get().getLifecycle()
                .addObserver(appOpenAdManager);

        // Pre-load the first App Open Ad
        appOpenAdManager.loadAd();

        Log.d(TAG, "Noor Al-Huda Application started.");
    }

    /**
     * Returns singleton instance of MyApplication.
     */
    public static MyApplication getInstance() {
        return instance;
    }

    /**
     * Returns the AppOpenAdManager for use in activities.
     */
    public AppOpenAdManager getAppOpenAdManager() {
        return appOpenAdManager;
    }
}
