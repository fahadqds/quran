# 🌙 Noor Al-Huda — Complete Android App

## نُورُ الْهُدَى — Your Islamic Companion

---

## 📋 Project Overview

**Noor Al-Huda** is a premium Islamic Android application built entirely in **Java**.
Dark emerald green + gold Islamic theme matching the uploaded UI design exactly.

---

## 🛠️ Technical Specifications

| Item | Value |
|------|-------|
| Language | Java (100%, NO Kotlin) |
| Min SDK | 24 (Android 7.0) |
| Target SDK | 36 |
| Compile SDK | 36 |
| Gradle Wrapper | 8.9 |
| AGP | 8.5.2 |
| ViewBinding | ✅ Enabled |
| Architecture | Single-module, Activity + Fragment |

---

## 📱 Screens Implemented

### 1. Splash Screen (`SplashActivity`)
- Dark emerald + gold radial gradient background
- Animated mosque logo (scale + fade in)
- Arabic calligraphy نُورُ الْهُدَى + English name
- Pulsing "Loading..." text
- App Open Ad on launch
- Auto-navigates to Home after 3 seconds

### 2. Home Screen (`HomeFragment` inside `MainActivity`)
- Personalized greeting "As-Salaam Alaykum, Ahmed"
- Current date display
- Prayer Times card (Fajr, Dhuhr, Asr, Maghrib, Isha)
  - Fetches from **Aladhan.com free API** (no key needed)
  - Shimmer loading effect while fetching
  - Highlights currently active prayer in gold
  - Qibla compass shortcut button
- 2×3 Feature Grid:
  - 📖 Quran
  - 📿 Tasbih
  - 🔊 Adhan
  - 🎨 Image Creator
  - 💰 Zakat Calculator
  - 🤲 Dua & Azkar
- All cards animated (staggered entrance + press scale)
- Interstitial Ad on every feature card tap

### 3. Tasbih Screen (`TasbihActivity`)
- Arabic calligraphy display (سُبْحَانَ اللَّهِ / الْحَمْدُ لِلَّهِ / اللَّهُ أَكْبَرُ)
- Circular gold ring progress indicator (0–99)
- Large animated counter number
- Animated "+" button with:
  - Haptic vibration feedback
  - Click beep sound
  - Number scale animation
- Reset button with confirmation dialog
- 3 dhikr preset chips: SubhanAllah, Alhamdulillah, AllahuAkbar
- **Saves & restores count** via SharedPreferences
- MashaAllah dialog on completing 99 count
- Banner Ad + Interstitial on back press

### 4. AI Image Creator (`AIImageCreatorActivity`)
- Title: "Islamic Art Studio"
- Image preview card (240dp)
- Save 💾 and Share ↗ action buttons
- Multi-line prompt TextInputEditText
- **CREATE button** — triggers Rewarded Ad first, then generates
- Style chips (Calligraphy, Nature, Minimalist, Geometric, Mandala, Mosque)
- Template prompt cards (horizontal RecyclerView)
- Uses **Pollinations.ai FREE API** — no key, unlimited, open
  - URL: `https://image.pollinations.ai/prompt/{encoded_prompt}`
- Image loaded via Glide, saveable to gallery
- Banner Ad + Interstitial on back/share

### 5. Zakat Calculator (`ZakatActivity`)
- Inputs: Cash, Gold, Silver, Stocks, Business Assets, Debts
- Live auto-calculation as user types
- Nisab threshold check ($5,500 USD ≈ 85g gold)
- Zakat = 2.5% of net zakatable wealth above Nisab
- Result card with status (obligatory / below nisab)
- Reset button clears all fields
- Banner Ad

### 6. Dua & Azkar (`DuaActivity`)
- 12 authentic duas with Arabic text, transliteration, translation
- Category badges (Morning, Daily, Night, Prayer, Family, etc.)
- Tap to expand/collapse transliteration + translation
- RecyclerView list
- Banner Ad

### 7. Adhan Player (`AdhanActivity`)
- Play/Pause button for Adhan audio
- Place `adhan_placeholder.mp3` in `res/raw/` to activate
- Banner Ad

### 8. Settings (`SettingsFragment` / `SettingsActivity`)
- User name customization
- Notifications toggle
- Vibration toggle
- Saved to SharedPreferences

### 9. Community (`CommunityFragment`)
- Placeholder screen — "Coming Soon!"

---

## 💰 AdMob Integration (Full)

| Ad Type | Where Used |
|---------|-----------|
| App Open Ad | App cold start, foreground resume (via `AppOpenAdManager`) |
| Banner Ad | Every activity/fragment — above bottom navigation |
| Interstitial Ad | Every feature card tap, every back press, navigation |
| Rewarded Ad | AI Image Creator — user watches ad to unlock generation |

### Ad Unit IDs (Test Mode)
All IDs are Google's official test IDs. **Replace before publishing:**

```
App Open:     ca-app-pub-3940256099942544/9257395921
Banner:       ca-app-pub-3940256099942544/6300978111
Interstitial: ca-app-pub-3940256099942544/1033173712
Rewarded:     ca-app-pub-3940256099942544/5224354917
App ID:       ca-app-pub-3940256099942544~3347511713
```

---

## 🌐 Free APIs Used

| API | Usage | Key Required |
|-----|-------|-------------|
| [Aladhan.com](http://api.aladhan.com) | Prayer times by city | ❌ None |
| [Pollinations.ai](https://image.pollinations.ai) | AI image generation | ❌ None |

---

## 📦 Key Dependencies

```gradle
// UI
com.google.android.material:material:1.12.0
androidx.constraintlayout:constraintlayout:2.2.1
androidx.recyclerview:recyclerview:1.4.0

// Images
com.github.bumptech.glide:glide:4.16.0

// Animations
com.airbnb.android:lottie:6.6.0
com.facebook.shimmer:shimmer:0.5.0

// Ads
com.google.android.gms:play-services-ads:23.6.0

// Network
com.squareup.retrofit2:retrofit:2.11.0
```

---

## 🚀 How to Open in Android Studio

1. **Unzip** `NoorAlHuda.zip`
2. Open **Android Studio** → `File` → `Open`
3. Select the `NoorAlHuda` folder
4. Wait for **Gradle sync** to complete
5. Click **▶ Run** on a device/emulator (API 24+)

---

## ⚠️ Before Publishing to Play Store

1. Replace all **test AdMob IDs** in `AdManager.java` with real IDs
2. Add your **real AdMob App ID** in `AndroidManifest.xml`
3. Add `adhan_placeholder.mp3` to `res/raw/` for Adhan audio
4. Update `DEFAULT_CITY` in `PrayerTimeHelper.java` or add GPS location
5. Enable `minifyEnabled true` in `build.gradle` for release builds
6. Sign the APK with your keystore

---

## 🎨 Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Dark Emerald | `#0D1F1A` | App background |
| Card Surface | `#122B22` | Card backgrounds |
| Primary Green | `#002B1B` | Primary brand |
| Gold Accent | `#D4AF37` | Highlights, icons, active states |
| Gold Light | `#F0C040` | Hover/focus gold |
| Emerald Bright | `#52B788` | CTA buttons |
| Text Primary | `#FFFFFF` | Main text |
| Text Secondary | `#B0BEC5` | Subtitle text |

---

## 📁 Project Structure

```
NoorAlHuda/
├── app/
│   ├── src/main/
│   │   ├── java/com/nooralhuda/app/
│   │   │   ├── MyApplication.java          ← App class + AdMob init
│   │   │   ├── activities/
│   │   │   │   ├── SplashActivity.java
│   │   │   │   ├── MainActivity.java
│   │   │   │   ├── TasbihActivity.java
│   │   │   │   ├── AIImageCreatorActivity.java
│   │   │   │   ├── ZakatActivity.java
│   │   │   │   ├── DuaActivity.java
│   │   │   │   ├── QuranActivity.java
│   │   │   │   ├── AdhanActivity.java
│   │   │   │   ├── SettingsActivity.java
│   │   │   │   └── CommunityActivity.java
│   │   │   ├── fragments/
│   │   │   │   ├── HomeFragment.java
│   │   │   │   ├── CommunityFragment.java
│   │   │   │   └── SettingsFragment.java
│   │   │   ├── adapters/
│   │   │   │   ├── DuaAdapter.java
│   │   │   │   ├── StyleChipAdapter.java
│   │   │   │   └── TemplateAdapter.java
│   │   │   ├── models/
│   │   │   │   └── DuaModel.java
│   │   │   ├── utils/
│   │   │   │   ├── PrayerTimeHelper.java   ← Aladhan API
│   │   │   │   ├── ImageApiHelper.java     ← Pollinations API
│   │   │   │   └── DateHelper.java
│   │   │   └── ads/
│   │   │       ├── AdManager.java          ← Banner/Interstitial/Rewarded
│   │   │       └── AppOpenAdManager.java   ← App Open Ad lifecycle
│   │   ├── res/
│   │   │   ├── layout/     ← All XML layouts
│   │   │   ├── drawable/   ← Vector icons + shapes
│   │   │   ├── values/     ← Colors, strings, themes, dimens
│   │   │   ├── anim/       ← Slide + fade animations
│   │   │   ├── menu/       ← Bottom navigation menu
│   │   │   ├── xml/        ← Backup rules
│   │   │   └── raw/        ← (Add adhan.mp3 here)
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── gradle/wrapper/gradle-wrapper.properties
```

---

*Built with ❤️ for the Muslim Ummah — Noor Al-Huda v1.0*
